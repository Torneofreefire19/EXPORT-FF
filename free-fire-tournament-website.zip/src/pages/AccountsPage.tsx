import { motion } from 'framer-motion';
import { Gamepad2, Phone } from 'lucide-react';
import PageBackground from '../components/PageBackground';
import { useAppContext } from '../context/AppContext';

export default function AccountsPage() {
  const { accountListings } = useAppContext();

  return (
    <PageBackground page="cuentas">
      <section className="py-20 text-white min-h-screen">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-4xl font-black uppercase italic mb-12 text-center text-orange-500">
            Compra y Venta de Cuentas
          </h1>
          
          {accountListings.length === 0 ? (
            <div className="text-center p-12 bg-neutral-900/80 rounded-3xl border border-white/10">
              <p className="text-neutral-400">No hay cuentas disponibles por el momento. Espera a que nuestros empleados publiquen nuevas ofertas.</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {accountListings.map((listing) => (
                <motion.div 
                    key={listing.id} 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-neutral-900/80 p-6 rounded-3xl border border-white/10 hover:border-orange-500/50 transition-all"
                >
                  <div className="flex items-center gap-4 mb-6 border-b border-white/10 pb-4">
                    <img src={listing.logo} alt={listing.logoName} className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <h2 className="text-xl font-bold">{listing.logoName}</h2>
                      <p className="text-xs text-orange-400 uppercase tracking-widest font-bold">{listing.phone}</p>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    {listing.media.length > 0 && (
                      listing.media[0].type === 'image' ? (
                        <img src={listing.media[0].src} alt="Cuenta" className="w-full h-40 object-cover rounded-xl mb-4" />
                      ) : (
                        <video src={listing.media[0].src} className="w-full h-40 object-cover rounded-xl mb-4" controls />
                      )
                    )}
                    <p className="text-sm text-gray-300 mb-4 h-20 overflow-hidden">{listing.description}</p>
                    <p className="text-3xl font-black text-orange-500 text-center">{listing.price} $</p>
                  </div>

                  <a 
                    href={`https://wa.me/${listing.phone.replace(/\D/g, '')}?text=Hola! Estoy interesado en la cuenta: ${listing.description.substring(0, 20)}...`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full bg-green-500 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-green-600 transition-all"
                  >
                    <Phone className="h-5 w-5" /> Contactar Vendedor
                  </a>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </PageBackground>
  );
}
