import { ChangeEvent, FormEvent, useState } from 'react';
import { Briefcase, ImageUp, Send } from 'lucide-react';
import PageShell from './PageShell';
import { getRequests, saveRequests, WorkRequest } from '../lib/storage';

const initialForm = {
  fullName: '',
  phone: '',
  workLogoName: '',
  logoImage: '',
  experience: '',
  reason: '',
};

const WorkRequestPage = () => {
  const [form, setForm] = useState(initialForm);
  const [sent, setSent] = useState(false);

  const updateField = (field: keyof typeof form, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handleLogo = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => updateField('logoImage', String(reader.result));
    reader.readAsDataURL(file);
  };

  const submitRequest = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const request: WorkRequest = {
      id: crypto.randomUUID(),
      ...form,
      status: 'pendiente',
      createdAt: new Date().toLocaleString('es-VE'),
    };

    saveRequests([request, ...getRequests()]);
    setForm(initialForm);
    setSent(true);
  };

  return (
    <PageShell
      eyebrow="Trabaja con nosotros"
      title="Solicitar Trabajo"
      description="Completa tu informacion. La solicitud llegara al panel de administrador, donde se revisara tu experiencia y se decidira si puedes trabajar en Torneo Export FF."
    >
      <form onSubmit={submitRequest} className="grid gap-8 rounded-[2rem] border border-white/10 bg-neutral-900/70 p-7 md:grid-cols-2 md:p-10">
        <div>
          <label className="mb-2 block text-xs font-black uppercase tracking-widest text-neutral-500">Nombre y apellido</label>
          <input required value={form.fullName} onChange={(e) => updateField('fullName', e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black/50 px-5 py-4 outline-none transition focus:border-orange-500" placeholder="Ej: Jose Perez" />
        </div>

        <div>
          <label className="mb-2 block text-xs font-black uppercase tracking-widest text-neutral-500">Numero de celular</label>
          <input required value={form.phone} onChange={(e) => updateField('phone', e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black/50 px-5 py-4 outline-none transition focus:border-orange-500" placeholder="04XX-XXXXXXX" />
        </div>

        <div>
          <label className="mb-2 block text-xs font-black uppercase tracking-widest text-neutral-500">Nombre de logo de trabajo</label>
          <input required value={form.workLogoName} onChange={(e) => updateField('workLogoName', e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black/50 px-5 py-4 outline-none transition focus:border-orange-500" placeholder="Ej: Recargas JP" />
        </div>

        <div>
          <label className="mb-2 block text-xs font-black uppercase tracking-widest text-neutral-500">Imagen del logo</label>
          <label className="flex cursor-pointer items-center justify-center gap-3 rounded-2xl border border-dashed border-orange-500/40 bg-orange-500/10 px-5 py-4 font-bold text-orange-400 transition hover:bg-orange-500/20">
            <ImageUp className="h-5 w-5" /> Subir logo
            <input type="file" accept="image/*" onChange={handleLogo} className="hidden" />
          </label>
        </div>

        {form.logoImage && (
          <div className="md:col-span-2">
            <p className="mb-3 text-xs font-black uppercase tracking-widest text-neutral-500">Vista previa del logo</p>
            <img src={form.logoImage} alt="Logo de trabajo" className="h-24 w-24 rounded-2xl border border-white/10 object-cover" />
          </div>
        )}

        <div className="md:col-span-2">
          <label className="mb-2 block text-xs font-black uppercase tracking-widest text-neutral-500">Experiencia</label>
          <select required value={form.experience} onChange={(e) => updateField('experience', e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black/50 px-5 py-4 outline-none transition focus:border-orange-500">
            <option value="">Selecciona tu experiencia</option>
            <option>Si tengo experiencia recargando diamantes</option>
            <option>Si tengo experiencia comprando y vendiendo cuentas de Free Fire</option>
            <option>Tengo experiencia en diamantes y cuentas</option>
            <option>No tengo experiencia, pero quiero aprender</option>
          </select>
        </div>

        <div className="md:col-span-2">
          <label className="mb-2 block text-xs font-black uppercase tracking-widest text-neutral-500">Por que quieres trabajar en Torneo Export FF?</label>
          <textarea required rows={5} value={form.reason} onChange={(e) => updateField('reason', e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black/50 px-5 py-4 outline-none transition focus:border-orange-500" placeholder="Explica tu motivacion, responsabilidad y experiencia..." />
        </div>

        <div className="md:col-span-2">
          <button className="inline-flex w-full items-center justify-center gap-3 rounded-2xl bg-orange-500 px-6 py-4 font-black uppercase tracking-widest text-black transition hover:bg-orange-400 md:w-auto">
            <Send className="h-5 w-5" /> Enviar al Administrador
          </button>
          {sent && <p className="mt-4 flex items-center gap-2 text-sm font-bold text-green-400"><Briefcase className="h-4 w-4" /> Solicitud enviada. El administrador la revisara.</p>}
        </div>
      </form>
    </PageShell>
  );
};

export default WorkRequestPage;