import { motion } from 'framer-motion';
import { Gem, Phone } from 'lucide-react';
import PageBackground from '../components/PageBackground';
import { useAppContext } from '../context/AppContext';

export default function DiamondsPage() {
  const { diamondOffers } = useAppContext();

  return (
    <PageBackground page="diamantes">
      <section className="py-20 text-white min-h-screen">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-black uppercase italic mb-12 text-center text-orange-500">
            Recargas de Diamantes
          </h1>
          
          {diamondOffers.length === 0 ? (
            <div className="text-center p-12 bg-neutral-900/80 rounded-3xl border border-white/10">
              <p className="text-neutral-400">No hay ofertas de diamantes publicadas por el momento.</p>
            </div>
          ) : (
            <div className="space-y-8">
            {diamondOffers.map((offer) => (
              <motion.div 
                  key={offer.id} 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-neutral-900/80 p-6 rounded-3xl border border-white/10"
              >
                <div className="flex items-center gap-4 mb-6 border-b border-white/10 pb-4">
                  <img src={offer.logo} alt={offer.logoName} className="w-12 h-12 rounded-full object-cover" />
                  <div>
                    <h2 className="text-xl font-bold">{offer.logoName}</h2>
                    <a 
                      href={`https://wa.me/${offer.phone.replace(/\D/g, '')}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-xs text-orange-400 uppercase tracking-widest font-bold hover:underline"
                    >
                      {offer.phone}
                    </a>
                  </div>
                </div>
                
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {offer.offers.map((o, i) => (
                      <div key={i} className="bg-black/50 p-4 rounded-xl border border-white/5 flex flex-col items-center text-center">
                        <Gem className="h-6 w-6 text-blue-400 mb-2" />
                        <p className="text-sm font-bold text-white">{o.amount}</p>
                        <p className="text-lg font-black text-orange-500">{o.price} $</p>
                        <p className="text-[10px] text-neutral-500 uppercase mt-1">Pago Móvil</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6">
                    <a 
                      href={`https://wa.me/${offer.phone.replace(/\D/g, '')}?text=Hola! Estoy interesado en recargar diamantes con ${offer.logoName}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="w-full bg-green-500 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-green-600 transition-all"
                    >
                      <Phone className="h-5 w-5" /> Contactar a {offer.logoName}
                    </a>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>
    </PageBackground>
  );
}
