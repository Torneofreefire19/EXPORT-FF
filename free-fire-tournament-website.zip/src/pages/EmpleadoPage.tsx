import { motion } from 'framer-motion';
import { User, AlertCircle, Plus, Trash2, Edit, Save, XCircle } from 'lucide-react';
import { useState } from 'react';
import { getEmployees, DiamondOffer } from '../lib/storage';
import PageBackground from '../components/PageBackground';
import { useAppContext, Employee } from '../context/AppContext';

const EmpleadoPage = () => {
  const [access, setAccess] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [employee, setEmployee] = useState<Employee | null>(null);
  
  const { 
    diamondOffers, addDiamondOffer, removeDiamondOffer, updateDiamondOffer, 
    accountListings, addAccountListing, removeAccountListing, updateAccountListing 
  } = useAppContext();
  const [diamondOffersForm, setDiamondOffersForm] = useState<{ amount: string; price: string }[]>(Array(12).fill({ amount: '', price: '' }));
  const [logoName, setLogoName] = useState('');
  const [logoImage, setLogoImage] = useState('');
  const [phone, setPhone] = useState('');
  
  const [editingOffer, setEditingOffer] = useState<DiamondOffer | null>(null);
  const [editForm, setEditForm] = useState<{ amount: string; price: string }[]>([]);
  const [accForm, setAccForm] = useState({ price: '', description: '', media: [] as {type: 'image'|'video', src: string}[] });
  
  const [editingAccount, setEditingAccount] = useState<any | null>(null);
  const [editAccForm, setEditAccForm] = useState({ price: '', description: '' });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const employees = getEmployees();
    const found = employees.find(e => e.access === access && e.password === password && e.active);
    
    if (found) {
      setEmployee(found);
      sessionStorage.setItem('isEmpleado', 'true');
      sessionStorage.setItem('empleadoId', found.id);
    } else {
      setError('Credenciales incorrectas o cuenta inactiva');
    }
  };

  const handleLogout = () => {
    setEmployee(null);
    setAccess('');
    setPassword('');
    sessionStorage.removeItem('isEmpleado');
    sessionStorage.removeItem('empleadoId');
  };

  const myOffers = diamondOffers.filter(o => o.sellerName === employee?.name);

  if (!employee) {
    return (
      <PageBackground page="empleado">
        <div className="relative z-10 max-w-md w-full px-4 py-20 min-h-screen flex items-center justify-center">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-neutral-900/90 border border-orange-500/20 rounded-3xl p-8 backdrop-blur-md w-full">
                <h2 className="text-2xl font-black uppercase italic text-center mb-6">Acceso Empleados</h2>
                <form onSubmit={handleLogin} className="space-y-4">
                    <input type="text" placeholder="Usuario (Acceso)" value={access} onChange={e => setAccess(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-orange-500" />
                    <input type="password" placeholder="Contraseña" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-orange-500" />
                    {error && <div className="text-red-400 text-sm flex items-center gap-2"><AlertCircle className="h-4 w-4" /> {error}</div>}
                    <button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-xl font-black uppercase">Iniciar Sesión</button>
                </form>
            </motion.div>
        </div>
      </PageBackground>
    );
  }

  return (
    <PageBackground page="empleado">
      <div className="relative z-10 max-w-6xl mx-auto px-4 py-20 text-white">
        <div className="flex justify-between items-center mb-8">
            <h1 className="text-4xl font-black uppercase italic text-orange-500">
              PUBLICACION DE RECARGA DE DIAMANTE
            </h1>
            <button onClick={handleLogout} className="bg-red-500 text-white px-6 py-3 rounded-xl font-black uppercase">Cerrar Sesión</button>
        </div>
        
        <div className="bg-neutral-900/80 p-8 rounded-3xl border border-white/10 mb-8">
            <h2 className="text-2xl font-black uppercase italic mb-6">Publicación de Cuentas</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <input placeholder="Nombre del Logo" value={logoName} onChange={e => setLogoName(e.target.value)} className="w-full bg-black p-3 rounded" />
                <input placeholder="Número de Celular" value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-black p-3 rounded" />
                <input type="file" onChange={e => {
                    const file = e.target.files?.[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => setLogoImage(reader.result as string);
                        reader.readAsDataURL(file);
                    }
                }} className="w-full bg-black p-3 rounded text-sm" />
            </div>
            <textarea placeholder="Descripción de la cuenta" value={accForm.description} onChange={e => setAccForm({...accForm, description: e.target.value})} className="w-full bg-black p-3 mb-3 rounded" />
            <input placeholder="Precio" value={accForm.price} onChange={e => setAccForm({...accForm, price: e.target.value})} className="w-full bg-black p-3 mb-3 rounded" />
            <input type="file" multiple accept="image/*,video/*" onChange={e => {
                const files = Array.from(e.target.files || []);
                const promises = files.map(file => {
                    return new Promise<{type: 'image'|'video', src: string}>((resolve) => {
                        const reader = new FileReader();
                        reader.onloadend = () => resolve({
                            type: file.type.startsWith('video/') ? 'video' : 'image',
                            src: reader.result as string
                        });
                        reader.readAsDataURL(file);
                    });
                });
                Promise.all(promises).then(media => setAccForm({...accForm, media}));
            }} className="w-full bg-black p-3 mb-3 rounded text-sm" />
            
            <button onClick={() => {
                addAccountListing({
                    id: Date.now().toString(),
                    sellerName: employee.name,
                    phone: phone,
                    logo: logoImage,
                    logoName: logoName,
                    price: accForm.price,
                    description: accForm.description,
                    media: accForm.media
                });
                alert('Cuenta publicada');
                setAccForm({ price: '', description: '', media: [] });
            }} className="w-full bg-blue-500 p-3 rounded font-bold">Publicar Cuenta</button>
        </div>

        <div className="bg-neutral-900/80 p-8 rounded-3xl border border-white/10 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <input placeholder="Nombre del Logo" value={logoName} onChange={e => setLogoName(e.target.value)} className="w-full bg-black p-3 rounded" />
                <input placeholder="Número de Celular" value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-black p-3 rounded" />
                <input type="file" onChange={e => {
                    const file = e.target.files?.[0];
                    if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => setLogoImage(reader.result as string);
                        reader.readAsDataURL(file);
                    }
                }} className="w-full bg-black p-3 rounded text-sm" />
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                {diamondOffersForm.map((offer, i) => (
                    <div key={i} className="bg-black/50 p-4 rounded-xl border border-white/5">
                        <p className="text-xs font-bold text-neutral-500 mb-2">Pack {i+1}</p>
                        <input placeholder="Diamantes" value={offer.amount} onChange={(e) => {
                            const newOffers = [...diamondOffersForm];
                            newOffers[i] = { ...newOffers[i], amount: e.target.value };
                            setDiamondOffersForm(newOffers);
                        }} className="w-full bg-transparent mb-2 text-sm border-b border-white/10 pb-1" />
                        <input placeholder="Precio ($)" value={offer.price} onChange={(e) => {
                            const newOffers = [...diamondOffersForm];
                            newOffers[i] = { ...newOffers[i], price: e.target.value };
                            setDiamondOffersForm(newOffers);
                        }} className="w-full bg-transparent text-sm border-b border-white/10 pb-1" />
                    </div>
                ))}
            </div>
            
                <button onClick={() => { 
                addDiamondOffer({
                    id: Date.now().toString(), 
                    sellerName: employee.name, 
                    sellerAccess: employee.access,
                    logo: logoImage,
                    logoName: logoName,
                    phone: phone,
                    offers: diamondOffersForm.filter(o => o.amount && o.price)
                }); 
                alert('Ofertas publicadas'); 
                setDiamondOffersForm(Array(12).fill({ amount: '', price: '' }));
            }} className="w-full bg-orange-500 text-black py-4 rounded-xl font-black uppercase tracking-widest hover:bg-orange-600 transition-all flex items-center justify-center gap-2">
                <Plus className="h-5 w-5" /> Publicar Ofertas
            </button>
        </div>

        <h2 className="text-2xl font-bold mb-6">Historial de Publicaciones</h2>
        <div className="grid gap-4">
            {myOffers.map(offer => (
                <div key={offer.id} className="bg-neutral-900 p-6 rounded-2xl flex items-center justify-between border border-white/5">
                    {editingOffer?.id === offer.id ? (
                        <div className="flex-1 grid grid-cols-3 gap-2">
                            {editForm.map((o, i) => (
                                <div key={i} className="bg-black p-2 rounded text-xs">
                                    <input value={o.amount} onChange={e => {
                                        const next = [...editForm]; next[i].amount = e.target.value; setEditForm(next);
                                    }} className="w-full bg-transparent border-b border-white/10" placeholder="Diamantes" />
                                    <input value={o.price} onChange={e => {
                                        const next = [...editForm]; next[i].price = e.target.value; setEditForm(next);
                                    }} className="w-full bg-transparent" placeholder="$" />
                                </div>
                            ))}
                            <button onClick={() => { updateDiamondOffer(offer.id, {...offer, offers: editForm.filter(o => o.amount && o.price)}); setEditingOffer(null); }} className="bg-green-500 p-2 rounded"><Save /></button>
                            <button onClick={() => setEditingOffer(null)} className="bg-red-500 p-2 rounded"><XCircle /></button>
                        </div>
                    ) : (
                        <>
                            <div>
                                <p className="font-bold">Diamantes: Publicación del {new Date(Number(offer.id)).toLocaleString()}</p>
                                <p className="text-sm text-neutral-400">{offer.offers.length} paquetes</p>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={() => { 
                                    const pass = prompt("Introduce tu contraseña para editar:");
                                    if(pass === employee.password) { setEditingOffer(offer); setEditForm(offer.offers); }
                                    else alert("Contraseña incorrecta");
                                }} className="p-2 bg-blue-500/20 text-blue-400 rounded-lg"><Edit className="h-5 w-5" /></button>
                                <button onClick={() => { 
                                    const pass = prompt("Introduce tu contraseña para eliminar:");
                                    if(pass === employee.password) { removeDiamondOffer(offer.id); }
                                    else alert("Contraseña incorrecta");
                                }} className="p-2 bg-red-500/20 text-red-400 rounded-lg"><Trash2 className="h-5 w-5" /></button>
                            </div>
                        </>
                    )}
                </div>
            ))}
            {/* Cuentas History */}
            {accountListings.filter(a => a.sellerName === employee.name).map(acc => (
                <div key={acc.id} className="bg-neutral-900 p-6 rounded-2xl flex items-center justify-between border border-white/5">
                     {editingAccount?.id === acc.id ? (
                        <div className="flex-1 grid grid-cols-2 gap-2">
                             <input value={editAccForm.price} onChange={e => setEditAccForm({...editAccForm, price: e.target.value})} className="bg-black p-2 rounded" placeholder="Precio ($)" />
                             <input value={editAccForm.description} onChange={e => setEditAccForm({...editAccForm, description: e.target.value})} className="bg-black p-2 rounded" placeholder="Descripción" />
                             <button onClick={() => { updateAccountListing(acc.id, {...acc, ...editAccForm}); setEditingAccount(null); }} className="bg-green-500 p-2 rounded">Guardar</button>
                             <button onClick={() => setEditingAccount(null)} className="bg-red-500 p-2 rounded">Cancelar</button>
                        </div>
                    ) : (
                        <>
                            <div>
                                <p className="font-bold">Cuenta: {acc.description.substring(0,20)}...</p>
                                <p className="text-sm text-orange-400">{acc.price} $</p>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={() => { 
                                    const pass = prompt("Introduce tu contraseña para editar:");
                                    if(pass === employee.password) { setEditingAccount(acc); setEditAccForm({price: acc.price, description: acc.description}); }
                                    else alert("Contraseña incorrecta");
                                }} className="p-2 bg-blue-500/20 text-blue-400 rounded-lg"><Edit className="h-5 w-5" /></button>
                                <button onClick={() => { 
                                    const pass = prompt("Introduce tu contraseña para eliminar:");
                                    if(pass === employee.password) { removeAccountListing(acc.id); }
                                    else alert("Contraseña incorrecta");
                                }} className="p-2 bg-red-500/20 text-red-400 rounded-lg"><Trash2 className="h-5 w-5" /></button>
                            </div>
                        </>
                    )}
                </div>
            ))}
        </div>
      </div>
    </PageBackground>
  );
};

export default EmpleadoPage;
