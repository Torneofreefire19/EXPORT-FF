import PageShell from './PageShell';

const modes = [
  {
    label: 'Modo uno',
    title: 'Battle Royale',
    description:
      'Cada kill que hagas te hace ganar $1. No importa si ganas o pierdes la partida, lo importante son las kills. Si haces 5 kills, estarias ganando $5 directamente a tu Pago Movil.',
  },
  {
    label: 'Modo dos',
    title: 'PvP 1vs1',
    description:
      'Este modo es uno contra uno. La persona que gana la partida gana su premio, o sea, su dinero. Cuando un jugador gana, el mismo puede tomar la decision de seguir jugando para ganar mas o retirar su dinero.',
  },
  {
    label: 'Modo tres',
    title: 'Torneo de Clan',
    description:
      'En este modo participan clanes de toda Venezuela. Si un clan gana la partida, recibira un premio y un anuncio especial reconociendolo como el mejor clan de toda Venezuela.',
  },
];

const DetailsPage = () => {
  return (
    <PageShell
      eyebrow="Detalles oficiales"
      title="Modos del Torneo"
      description="Conoce las tres formas de competir y ganar dinero dentro de Torneo Export FF."
    >
      <div className="space-y-6">
        {modes.map((mode) => (
          <section key={mode.title} className="rounded-[2rem] border border-white/10 bg-neutral-900/70 p-7 md:p-9">
            {mode.title === 'Battle Royale' && (
              <img
                src="/images/detail-battle-royale.jpg"
                alt="Modo Battle Royale Free Fire"
                className="mb-7 h-64 w-full rounded-[1.5rem] object-cover md:h-96"
              />
            )}
            {mode.title === 'PvP 1vs1' && (
              <img
                src="/images/detail-pvp.jpg"
                alt="Modo PvP 1vs1"
                className="mb-7 h-64 w-full rounded-[1.5rem] object-cover md:h-96"
              />
            )}
            {mode.title === 'Torneo de Clan' && (
              <img
                src="/images/detail-clan.jpg"
                alt="Modo Torneo de Clan"
                className="mb-7 h-64 w-full rounded-[1.5rem] object-cover md:h-96"
              />
            )}
            <p className="mb-3 text-xs font-black uppercase tracking-[0.25em] text-orange-400">{mode.label}</p>
            <h2 className="text-3xl font-black uppercase italic text-white md:text-4xl">{mode.title}</h2>
            <p className="mt-5 max-w-4xl text-lg leading-relaxed text-neutral-300">{mode.description}</p>
          </section>
        ))}
      </div>
    </PageShell>
  );
};

export default DetailsPage;