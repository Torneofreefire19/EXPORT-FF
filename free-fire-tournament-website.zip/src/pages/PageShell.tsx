import { useEffect, useState, type ReactNode } from 'react';
import MediaBackground from '../components/MediaBackground';
import { getPageMedia, PageKey, PageMedia } from '../lib/storage';

type PageShellProps = {
  eyebrow: string;
  title: string;
  description: string;
  children: ReactNode;
  pageKey?: PageKey;
  fallbackImage?: string;
};

const PageShell = ({ eyebrow, title, description, children, pageKey, fallbackImage = '/images/hero-bg.jpg' }: PageShellProps) => {
  const [pageMedia, setPageMedia] = useState<PageMedia | null>(null);

  useEffect(() => {
    if (pageKey) setPageMedia(getPageMedia(pageKey));
  }, [pageKey]);

  return (
    <section className="relative min-h-screen overflow-hidden bg-[#050505] px-4 pb-20 pt-32 text-white sm:px-6 lg:px-8">
      {pageKey && <MediaBackground media={pageMedia} fallbackImage={fallbackImage} overlayClassName="bg-black/75" />}
      <div className="relative z-10 mx-auto max-w-7xl">
        <div className="mb-12 max-w-3xl">
          <p className="mb-4 text-xs font-black uppercase tracking-[0.3em] text-orange-400">{eyebrow}</p>
          <h1 className="text-4xl font-black uppercase italic tracking-tight md:text-6xl">{title}</h1>
          <p className="mt-5 text-lg leading-relaxed text-neutral-400">{description}</p>
        </div>
        {children}
      </div>
    </section>
  );
};

export default PageShell;