import { useEffect, useState } from 'react';
import MediaBackground from '../components/MediaBackground';
import { ClanRank, PageMedia, getClans, getPageMedia } from '../lib/storage';

const ClanRankingPage = () => {
  const [clans, setClans] = useState<ClanRank[]>([]);
  const [pageMedia, setPageMedia] = useState<PageMedia | null>(null);

  useEffect(() => {
    setClans(getClans().sort((a, b) => a.rank - b.rank));
    setPageMedia(getPageMedia('clasificacion'));
  }, []);

  return (
    <section className="relative min-h-screen overflow-hidden px-4 pb-20 pt-28 text-white sm:px-6 lg:px-8">
      <MediaBackground media={pageMedia} fallbackImage="/images/ranking-bg.jpg" overlayClassName="bg-black/70" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-[#05050c]/70 to-black" />

      <div className="relative z-10 mx-auto max-w-7xl">
        <div className="mb-8">
          <p className="text-xs font-black uppercase tracking-[0.35em] text-orange-400">Torneo Export FF</p>
          <h1 className="mt-3 text-4xl font-black uppercase italic tracking-tight md:text-6xl">Tabla de Clasificaciones</h1>
          <p className="mt-3 text-neutral-300">Ranking oficial de clanes de Free Fire en Venezuela.</p>
        </div>

        <div className="overflow-hidden border border-white/10 bg-[#070711]/90 shadow-[0_25px_80px_rgba(0,0,0,0.55)] backdrop-blur-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] border-collapse text-left">
              <thead className="bg-gradient-to-b from-[#7b3419] to-[#351206] text-xs font-black uppercase tracking-widest text-white">
                <tr>
                  <th className="w-[12%] px-6 py-5">Pos</th>
                  <th className="w-[34%] px-6 py-5">Equipo</th>
                  <th className="w-[14%] px-6 py-5 text-center">Rondas</th>
                  <th className="w-[14%] px-6 py-5 text-center">Matar</th>
                  <th className="w-[14%] px-6 py-5 text-center">Booyahs</th>
                  <th className="w-[12%] px-6 py-5 text-right">Puntos</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {clans.map((clan) => (
                  <tr key={clan.id} className="bg-[#05050c]/80 text-neutral-200 transition hover:bg-white/5">
                    <td className="px-6 py-6 text-lg font-black text-orange-400">#{clan.rank}</td>
                    <td className="px-6 py-6 text-lg font-black text-white">{clan.clanName}</td>
                    <td className="px-6 py-6 text-center text-base font-medium">{clan.rounds}</td>
                    <td className="px-6 py-6 text-center text-base font-medium">{clan.kills}</td>
                    <td className="px-6 py-6 text-center text-base font-medium">{clan.booyahs}</td>
                    <td className="px-6 py-6 text-right text-lg font-black text-orange-400">{clan.points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ClanRankingPage;