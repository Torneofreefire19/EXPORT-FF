import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from 'react';
import { Image, Pencil, Plus, Save, Trash2, Upload, UserCheck, UserX, Video, XCircle } from 'lucide-react';
import PageShell from './PageShell';
import {
  ClanRank,
  Employee,
  HomeMedia,
  PageKey,
  ScheduleMode,
  ScheduleSlot,
  WorkRequest,
  WhatsAppLinks,
  getClans,
  getEmployees,
  getHomeMedia,
  getAllPageMedia,
  getRequests,
  getSchedule,
  getWhatsAppLinks,
  getAdminCreds,
  saveClans,
  saveEmployees,
  saveHomeMedia,
  savePageMedia,
  saveRequests,
  saveSchedule,
  saveWhatsAppLinks,
  saveAdminCreds,
  removeHomeMedia,
  removePageMedia,
  pageKeys,
  pageLabels,
  scheduleDays,
  scheduleModes,
  scheduleTimes,
} from '../lib/storage';
import { useAppContext } from '../context/AppContext';

const emptyEmployee = { name: '', logoName: '', access: '', password: '', phone: '' };
const emptyClan = { rank: '1', clanName: '', leader: '', rounds: '', kills: '', booyahs: '', points: '' };
const emptySchedule: { day: string; time: string; mode: ScheduleMode } = { day: 'Lunes', time: '6:00 PM', mode: 'Batle Royale' };

const getYouTubeEmbedUrl = (url: string) => {
  const patterns = [
    /youtube\.com\/watch\?v=([^&]+)/,
    /youtu\.be\/([^?&]+)/,
    /youtube\.com\/embed\/([^?&]+)/,
    /youtube\.com\/shorts\/([^?&]+)/,
  ];

  const match = patterns.map((pattern) => url.match(pattern)?.[1]).find(Boolean);
  return match ? `https://www.youtube.com/embed/${match}?controls=0&rel=0&modestbranding=1&iv_load_policy=3&disablekb=1&fs=0&playsinline=1` : '';
};

const getFileMediaType = (url: string): HomeMedia['type'] => {
  const cleanUrl = url.split('?')[0].toLowerCase();
  return /\.(mp4|webm|ogg|mov|m4v)$/.test(cleanUrl) ? 'video' : 'image';
};

  const AdminPage = () => {
  const [requests, setRequests] = useState<WorkRequest[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [clans, setClans] = useState<ClanRank[]>([]);
  const [schedule, setSchedule] = useState<ScheduleSlot[]>([]);
  const [whatsappForm, setWhatsappForm] = useState<WhatsAppLinks>(getWhatsAppLinks());
  const [homeMedia, setHomeMedia] = useState<HomeMedia | null>(null);
  const [pageMediaByKey, setPageMediaByKey] = useState<Partial<Record<PageKey, HomeMedia>>>({});
  const [selectedMediaPage, setSelectedMediaPage] = useState<PageKey>('inicio');
  const [employeeForm, setEmployeeForm] = useState(emptyEmployee);
  const [clanForm, setClanForm] = useState(emptyClan);
  const [editingClanId, setEditingClanId] = useState<string | null>(null);
  const [clanEditForm, setClanEditForm] = useState(emptyClan);
  const [scheduleForm, setScheduleForm] = useState(emptySchedule);
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [bgForm, setBgForm] = useState<HomeMedia>({ type: 'image', src: '', name: '', updatedAt: '', brightness: 100 });
  const [message, setMessage] = useState('');
  const [adminCreds, setAdminCreds] = useState(getAdminCreds());
  const [newPassword, setNewPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(sessionStorage.getItem('isAdmin') === 'true');
  const [loginPass, setLoginPass] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const { seasonInfo, setSeasonInfo } = useAppContext();
  const [seasonText, setSeasonText] = useState(seasonInfo.text);
  const [seasonActive, setSeasonActive] = useState(seasonInfo.active);

  const saveSeason = () => {
    setSeasonInfo({ text: seasonText, active: seasonActive });
    setMessage('Temporada actualizada.');
  };

  const handleLogin = (e: FormEvent) => {
    e.preventDefault();
    if (loginPass === adminCreds.pass) {
      sessionStorage.setItem('isAdmin', 'true');
      setIsLoggedIn(true);
    } else {
      setMessage('Contraseña incorrecta.');
      setLoginPass('');
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-black p-4">
        <form onSubmit={handleLogin} className="w-full max-w-sm rounded-3xl border border-orange-500/20 bg-neutral-900 p-8 text-white shadow-2xl">
          <h2 className="mb-6 text-center text-2xl font-black uppercase tracking-widest text-orange-500">Acceso Admin</h2>
          
          <div className="relative mb-4">
            <input 
              type={showPassword ? "text" : "password"} 
              className="w-full rounded-xl bg-black/50 p-4 pr-12 text-white border border-white/10 outline-none focus:border-orange-500" 
              placeholder="Ingrese contraseña" 
              value={loginPass} 
              onChange={e => { setLoginPass(e.target.value); setMessage(''); }} 
            />
            <button 
              type="button" 
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white text-xs font-bold"
            >
              {showPassword ? 'OCULTAR' : 'VER'}
            </button>
          </div>

          {message && <p className="mb-4 text-center text-sm font-bold text-red-500">{message}</p>}
          <button className="w-full rounded-xl bg-orange-500 py-4 font-black uppercase tracking-widest text-black hover:bg-orange-600 transition">Ingresar</button>
        </form>
      </div>
    );
  }

  useEffect(() => {
    setRequests(getRequests());
    setEmployees(getEmployees());
    setClans(getClans());
    setSchedule(getSchedule());
    setWhatsappForm(getWhatsAppLinks());
    setAdminCreds(getAdminCreds());
    const savedPageMedia = getAllPageMedia();
    const savedHomeMedia = savedPageMedia.inicio ?? getHomeMedia();
    setPageMediaByKey(savedPageMedia);
    setHomeMedia(savedHomeMedia);
    if (savedHomeMedia?.type === 'youtube') setYoutubeUrl(savedHomeMedia.src);
    if (savedHomeMedia?.type === 'image' || savedHomeMedia?.type === 'video') setFileUrl(savedHomeMedia.src.startsWith('data:') ? '' : savedHomeMedia.src);
  }, []);

  const updateAdminPassword = (e: FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      setMessage('La contraseña debe tener al menos 8 caracteres.');
      return;
    }
    const updatedCreds = { ...adminCreds, pass: newPassword };
    saveAdminCreds(updatedCreds);
    setAdminCreds(updatedCreds);
    setNewPassword('');
    setMessage('Contraseña de administrador actualizada.');
  };

  const pendingRequests = useMemo(() => requests.filter((request) => request.status === 'pendiente'), [requests]);
  const sortedClans = useMemo(() => [...clans].sort((a, b) => a.rank - b.rank), [clans]);
  const activeScheduleSlots = useMemo(
    () => new Map(schedule.map((slot) => [`${slot.day}-${slot.time}`, slot.mode ?? 'Batle Royale'])),
    [schedule],
  );

  const persistEmployees = (next: Employee[]) => {
    setEmployees(next);
    saveEmployees(next);
  };

  const removeEmployee = (id: string) => {
    const next = employees.filter(e => e.id !== id);
    persistEmployees(next);
  };

  const persistRequests = (next: WorkRequest[]) => {
    setRequests(next);
    saveRequests(next);
  };

  const persistClans = (next: ClanRank[]) => {
    setClans(next);
    saveClans(next);
  };

  const persistSchedule = (next: ScheduleSlot[]) => {
    setSchedule(next);
    saveSchedule(next);
  };

  const submitWhatsappLinks = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    saveWhatsAppLinks(whatsappForm);
    setMessage('Enlaces de WhatsApp de inscripción actualizados.');
  };

  const updateWhatsappEntry = (key: keyof WhatsAppLinks, field: 'url' | 'image', value: string) => {
    setWhatsappForm((current) => ({
      ...current,
      [key]: { ...current[key], [field]: value },
    }));
  };

  const uploadWhatsappImage = (key: keyof WhatsAppLinks, event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setMessage('Solo puedes subir imagenes para los enlaces de WhatsApp.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => updateWhatsappEntry(key, 'image', String(reader.result));
    reader.readAsDataURL(file);
  };

  const handleHomeMediaUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      setMessage('Solo puedes subir imagenes o videos para la pagina de inicio.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const media: HomeMedia = {
        type: file.type.startsWith('video/') ? 'video' : 'image',
        src: String(reader.result),
        name: file.name,
        updatedAt: new Date().toLocaleString('es-VE'),
        brightness: 100,
      };

      setPageMediaByKey((current) => ({ ...current, [selectedMediaPage]: media }));
      if (selectedMediaPage === 'inicio') setHomeMedia(media);
      savePageMedia(selectedMediaPage, media);
      setMessage(`Multimedia de ${pageLabels[selectedMediaPage]} actualizada correctamente.`);
    };
    reader.readAsDataURL(file);
  };

  const clearHomeMedia = () => {
    removePageMedia(selectedMediaPage);
    if (selectedMediaPage === 'inicio') {
      removeHomeMedia();
      setHomeMedia(null);
      setYoutubeUrl('');
    }
    setPageMediaByKey((current) => {
      const next = { ...current };
      delete next[selectedMediaPage];
      return next;
    });
    setMessage(`Se elimino la multimedia personalizada de ${pageLabels[selectedMediaPage]}.`);
  };

  const saveYouTubeBackground = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const embedUrl = getYouTubeEmbedUrl(youtubeUrl.trim());

    if (!embedUrl) {
      setMessage('Coloca un enlace valido de YouTube.');
      return;
    }

    const media: HomeMedia = {
      type: 'youtube',
      src: embedUrl,
      name: 'Video de YouTube',
      updatedAt: new Date().toLocaleString('es-VE'),
      brightness: 100,
    };

    if (selectedMediaPage !== 'inicio') {
      setMessage('YouTube solo esta disponible para el fondo de la pagina de inicio.');
      return;
    }

    setHomeMedia(media);
    setPageMediaByKey((current) => ({ ...current, inicio: media }));
    setYoutubeUrl(embedUrl);
    saveHomeMedia(media);
    savePageMedia('inicio', media);
    setMessage('Video de YouTube agregado al fondo de inicio.');
  };

  const saveFileUrlBackground = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const url = fileUrl.trim();

    if (!/^https?:\/\//i.test(url)) {
      setMessage('Coloca un enlace URL valido que empiece con http:// o https://.');
      return;
    }

    const media: HomeMedia = {
      type: getFileMediaType(url),
      src: url,
      name: `URL externa - ${pageLabels[selectedMediaPage]}`,
      updatedAt: new Date().toLocaleString('es-VE'),
      brightness: 100,
    };

    setPageMediaByKey((current) => ({ ...current, [selectedMediaPage]: media }));
    if (selectedMediaPage === 'inicio') setHomeMedia(media);
    savePageMedia(selectedMediaPage, media);
    setMessage(`URL de archivo agregada al fondo de ${pageLabels[selectedMediaPage]}.`);
  };

  const addEmployee = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const employee: Employee = { id: crypto.randomUUID(), ...employeeForm, active: true, phone: '' };
    persistEmployees([...employees, employee]);
    setEmployeeForm(emptyEmployee);
    setMessage('Empleado agregado correctamente.');
  };

  const acceptRequest = (request: WorkRequest) => {
    const employee: Employee = {
      id: crypto.randomUUID(),
      name: request.fullName,
      logoName: request.workLogoName,
      access: request.phone,
      password: `EXP-${Math.floor(1000 + Math.random() * 9000)}`,
      active: true,
      phone: request.phone,
    };

    persistEmployees([...employees, employee]);
    persistRequests(requests.map((item) => (item.id === request.id ? { ...item, status: 'aceptado' } : item)));
    setMessage(`Solicitud aceptada. Contraseña asignada: ${employee.password}`);
  };

  const rejectRequest = (requestId: string) => {
    persistRequests(requests.map((item) => (item.id === requestId ? { ...item, status: 'rechazado' } : item)));
    setMessage('Solicitud rechazada.');
  };

  const fireEmployee = (employeeId: string) => {
    persistEmployees(employees.map((employee) => (employee.id === employeeId ? { ...employee, active: false } : employee)));
    setMessage('Empleado despedido y marcado como inactivo.');
  };

  const addClan = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const rank = Number(clanForm.rank);

    if (rank < 1 || rank > 100) {
      setMessage('El numero del clan debe estar entre 1 y 100.');
      return;
    }

    if (clans.some((clan) => clan.rank === rank)) {
      setMessage('Ese puesto ya esta ocupado. Elimina el clan actual antes de usarlo.');
      return;
    }

    const clan: ClanRank = {
      id: crypto.randomUUID(),
      rank,
      clanName: clanForm.clanName,
      leader: clanForm.leader,
      rounds: Number(clanForm.rounds),
      kills: Number(clanForm.kills),
      booyahs: Number(clanForm.booyahs),
      points: Number(clanForm.points),
    };

    persistClans([...clans, clan]);
    setClanForm(emptyClan);
    setMessage('Clan agregado a la tabla de clasificacion.');
  };

  const deleteClan = (clanId: string) => {
    persistClans(clans.filter((clan) => clan.id !== clanId));
    if (editingClanId === clanId) setEditingClanId(null);
    setMessage('Clan eliminado de la clasificacion.');
  };

  const startEditingClan = (clan: ClanRank) => {
    setEditingClanId(clan.id);
    setClanEditForm({
      rank: String(clan.rank),
      clanName: clan.clanName,
      leader: clan.leader,
      rounds: String(clan.rounds),
      kills: String(clan.kills),
      booyahs: String(clan.booyahs),
      points: String(clan.points),
    });
  };

  const cancelEditingClan = () => {
    setEditingClanId(null);
    setClanEditForm(emptyClan);
  };

  const saveEditedClan = (clanId: string) => {
    const rank = Number(clanEditForm.rank);

    if (rank < 1 || rank > 100) {
      setMessage('El numero del clan debe estar entre 1 y 100.');
      return;
    }

    if (clans.some((clan) => clan.id !== clanId && clan.rank === rank)) {
      setMessage('Ese puesto ya esta ocupado por otro equipo.');
      return;
    }

    persistClans(clans.map((clan) => (clan.id === clanId ? {
      ...clan,
      rank,
      clanName: clanEditForm.clanName,
      leader: clanEditForm.leader,
      rounds: Number(clanEditForm.rounds),
      kills: Number(clanEditForm.kills),
      booyahs: Number(clanEditForm.booyahs),
      points: Number(clanEditForm.points),
    } : clan)));

    cancelEditingClan();
    setMessage('Equipo editado correctamente en la tabla de clasificacion.');
  };

  const setScheduleSlot = (day: string, time: string, mode: ScheduleMode) => {
    const exists = schedule.some((slot) => slot.day === day && slot.time === time);

    if (exists) {
      persistSchedule(schedule.map((slot) => (slot.day === day && slot.time === time ? { ...slot, mode } : slot)));
      setMessage(`Horario actualizado: ${day} ${time} - ${mode}.`);
      return;
    }

    persistSchedule([...schedule, { id: `${day}-${time}`, day, time, mode }]);
    setMessage(`Torneo agregado al horario: ${day} ${time} - ${mode}.`);
  };

  const toggleScheduleSlot = (day: string, time: string) => {
    const exists = schedule.some((slot) => slot.day === day && slot.time === time);

    if (exists) {
      persistSchedule(schedule.filter((slot) => !(slot.day === day && slot.time === time)));
      setMessage(`Horario liberado: ${day} ${time}.`);
      return;
    }

    persistSchedule([...schedule, { id: `${day}-${time}`, day, time, mode: scheduleForm.mode }]);
    setMessage(`Torneo agregado al horario: ${day} ${time} - ${scheduleForm.mode}.`);
  };

  const submitScheduleSlot = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setScheduleSlot(scheduleForm.day, scheduleForm.time, scheduleForm.mode);
  };

  const selectedPageMedia = pageMediaByKey[selectedMediaPage] ?? (selectedMediaPage === 'inicio' ? homeMedia : null);

  return (
    <PageShell
      eyebrow="Panel interno"
      title="Administrador"
      description="Gestiona solicitudes de trabajo, empleados activos y la tabla nacional de clanes de Free Fire de Venezuela."
    >
      <div className="mb-8 flex justify-end">
        <button 
            onClick={() => { sessionStorage.removeItem('isAdmin'); window.location.reload(); }}
            className="rounded-xl bg-red-600 px-6 py-3 font-black uppercase tracking-widest text-white hover:bg-red-500 transition"
        >
            Cerrar Sesión
        </button>
      </div>
      {message && <div className="mb-8 rounded-2xl border border-orange-500/30 bg-orange-500/10 p-4 font-bold text-orange-300">{message}</div>}

      <div className="mb-12 rounded-[2rem] border border-white/10 bg-neutral-900/70 p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-black uppercase italic">Enlaces de WhatsApp para inscripción</h2>
          <p className="mt-2 text-sm text-neutral-400">Estos enlaces aparecen en la pagina de Inscripción para que los jugadores entren a cada grupo.</p>
        </div>

        <form onSubmit={submitWhatsappLinks} className="grid gap-5 lg:grid-cols-3">
          {([
            ['battleRoyale', 'Modo 1 - Batle Royale'],
            ['pvp', 'Modo 2 - PVP 1vs1'],
            ['clanes', 'Modo 3 - Torneo de Clan'],
          ] as [keyof WhatsAppLinks, string][]).map(([key, label]) => (
            <div key={key} className="rounded-2xl border border-white/10 bg-black/35 p-4">
              <span className="mb-3 block text-xs font-black uppercase tracking-widest text-orange-400">{label}</span>

              <img src={whatsappForm[key].image} alt={label} className="mb-3 h-32 w-full rounded-xl object-cover" />

              <label className="mb-3 block">
                <span className="mb-1 block text-[11px] font-bold uppercase text-neutral-500">Enlace WhatsApp</span>
                <input
                  value={whatsappForm[key].url}
                  onChange={(event) => updateWhatsappEntry(key, 'url', event.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 text-sm text-white outline-none focus:border-orange-500"
                  placeholder="https://chat.whatsapp.com/..."
                />
              </label>

              <label className="mb-3 block">
                <span className="mb-1 block text-[11px] font-bold uppercase text-neutral-500">URL de imagen</span>
                <input
                  value={whatsappForm[key].image}
                  onChange={(event) => updateWhatsappEntry(key, 'image', event.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 text-sm text-white outline-none focus:border-orange-500"
                  placeholder="https://ejemplo.com/imagen.jpg"
                />
              </label>

              <label className="inline-flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-orange-500/40 bg-orange-500/10 px-4 py-3 text-xs font-black uppercase text-orange-300 transition hover:bg-orange-500/20">
                <Upload className="h-4 w-4" /> Subir imagen
                <input type="file" accept="image/*" onChange={(event) => uploadWhatsappImage(key, event)} className="hidden" />
              </label>
            </div>
          ))}

          <button className="rounded-xl bg-green-500 px-5 py-4 font-black uppercase tracking-widest text-black transition hover:bg-green-400 lg:col-span-3">
            Guardar enlaces de WhatsApp
          </button>
        </form>
      </div>

        <div className="mb-12 rounded-[2rem] border border-white/10 bg-neutral-900/70 p-6">
          <h2 className="mb-5 text-2xl font-black uppercase italic">Seguridad Admin</h2>
          <form onSubmit={updateAdminPassword} className="flex gap-4">
            <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="flex-1 rounded-xl border border-white/10 bg-black/50 px-4 py-3 text-sm text-white outline-none" placeholder="Nueva contraseña" />
            <button className="rounded-xl bg-orange-500 px-5 py-3 font-black uppercase text-black">Cambiar contraseña</button>
          </form>
          <div className="mt-8 border-t border-white/10 pt-8">
            <h2 className="mb-5 text-2xl font-black uppercase italic">Configuración Temporada</h2>
            <div className="flex gap-4 items-center">
              <input value={seasonText} onChange={e => setSeasonText(e.target.value)} className="flex-1 rounded-xl border border-white/10 bg-black/50 px-4 py-3 text-sm text-white outline-none" />
              <label className="flex items-center gap-2 text-sm font-bold">
                <input type="checkbox" checked={seasonActive} onChange={e => setSeasonActive(e.target.checked)} /> Activa
              </label>
              <button onClick={saveSeason} className="rounded-xl bg-orange-500 px-5 py-3 font-black uppercase text-black">Guardar Temporada</button>
            </div>
          </div>
        </div>

      <div className="mb-12 rounded-[2rem] border border-white/10 bg-neutral-900/70 p-6">
        <div className="mb-6 flex flex-col justify-between gap-5 lg:flex-row lg:items-center">
          <div>
            <h2 className="text-2xl font-black uppercase italic">Fondos de paginas</h2>
            <p className="mt-2 text-sm text-neutral-400">Elige una pagina y agrega una imagen o video desde tu dispositivo. Para Inicio tambien puedes pegar un enlace de YouTube.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <select
              value={selectedMediaPage}
              onChange={(event) => {
                const page = event.target.value as PageKey;
                setSelectedMediaPage(page);
                const media = pageMediaByKey[page] ?? (page === 'inicio' ? homeMedia : null);
                setYoutubeUrl(media?.type === 'youtube' ? media.src : '');
                setFileUrl((media?.type === 'image' || media?.type === 'video') && !media.src.startsWith('data:') ? media.src : '');
              }}
              className="rounded-xl border border-white/10 bg-black/50 px-4 py-3 font-bold text-white outline-none focus:border-orange-500"
            >
              {pageKeys.map((page) => <option key={page} value={page}>{pageLabels[page]}</option>)}
            </select>
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-orange-500 px-5 py-3 font-black uppercase text-black transition hover:bg-orange-400">
              <Upload className="h-4 w-4" /> Subir foto/video
              <input type="file" accept="image/*,video/*" onChange={handleHomeMediaUpload} className="hidden" />
            </label>
            {selectedPageMedia && (
              <button onClick={clearHomeMedia} className="rounded-xl bg-red-500 px-5 py-3 font-black uppercase text-white transition hover:bg-red-400">
                Quitar
              </button>
            )}
          </div>
        </div>

        {selectedMediaPage === 'inicio' && <form onSubmit={saveYouTubeBackground} className="mb-6 flex flex-col gap-3 rounded-2xl border border-white/10 bg-black/35 p-4 lg:flex-row">
          <input
            value={youtubeUrl}
            onChange={(event) => setYoutubeUrl(event.target.value)}
            className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/50 px-4 py-3 text-white outline-none focus:border-orange-500"
            placeholder="Pega aqui el enlace de YouTube"
          />
          <button className="inline-flex items-center justify-center gap-2 rounded-xl bg-red-600 px-5 py-3 font-black uppercase text-white transition hover:bg-red-500">
            <Video className="h-4 w-4" /> Usar YouTube
          </button>
        </form>}

        {selectedMediaPage === 'inicio' && (
          <div className="mb-6 rounded-2xl bg-slate-200 p-4 text-slate-600">
            <p className="mb-4 text-sm font-bold">Subir video</p>
            <label className="flex cursor-pointer items-center justify-center gap-3 rounded-xl border border-dashed border-red-300 bg-white/30 px-5 py-5 text-sm font-black text-red-500 transition hover:bg-white/60">
              <Upload className="h-4 w-4" /> Subir video
              <input
                type="file"
                accept="video/mp4,video/webm,video/quicktime,video/x-msvideo,video/x-matroska,video/x-ms-wmv,video/x-m4v,video/ogg,video/3gpp"
                onChange={handleHomeMediaUpload}
                className="hidden"
              />
            </label>
            <p className="mt-3 text-sm">
              Archivo actual: {selectedPageMedia?.type === 'video' ? selectedPageMedia.name : 'Archivo personalizado'}
            </p>
            <p className="mt-2 text-sm text-slate-500">Formatos soportados: MP4, WebM, MOV, AVI, MKV, WMV, M4V, OGV, 3GP</p>
          </div>
        )}

        <form onSubmit={saveFileUrlBackground} className="mb-6 flex flex-col gap-3 rounded-2xl border border-white/10 bg-black/35 p-4 lg:flex-row">
          <input
            value={fileUrl}
            onChange={(event) => setFileUrl(event.target.value)}
            className="min-w-0 flex-1 rounded-xl border border-white/10 bg-black/50 px-4 py-3 text-white outline-none focus:border-orange-500"
            placeholder="Pega aqui la URL directa de una imagen o video"
          />
          <button className="inline-flex items-center justify-center gap-2 rounded-xl bg-orange-500 px-5 py-3 font-black uppercase text-black transition hover:bg-orange-400">
            <Upload className="h-4 w-4" /> Usar URL de archivo
          </button>
        </form>

        <div className="rounded-2xl border border-white/10 bg-black/35 p-4">
          {selectedPageMedia ? (
            <div className="grid gap-5 lg:grid-cols-[280px_1fr] lg:items-center">
              {selectedPageMedia.type === 'video' ? (
                <video src={selectedPageMedia.src} controls className="h-40 w-full rounded-xl object-cover" />
              ) : selectedPageMedia.type === 'youtube' ? (
                <iframe src={selectedPageMedia.src} title={selectedPageMedia.name} className="h-40 w-full rounded-xl" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen />
              ) : (
                <img src={selectedPageMedia.src} alt={selectedPageMedia.name} className="h-40 w-full rounded-xl object-cover" />
              )}
              <div>
                <div className="mb-3 flex items-center gap-3 text-orange-400">
                  {selectedPageMedia.type === 'image' ? <Image className="h-6 w-6" /> : <Video className="h-6 w-6" />}
                  <p className="font-black uppercase">{selectedPageMedia.type === 'image' ? `Imagen activa en ${pageLabels[selectedMediaPage]}` : selectedPageMedia.type === 'youtube' ? 'YouTube activo en inicio' : `Video activo en ${pageLabels[selectedMediaPage]}`}</p>
                </div>
                <p className="text-sm text-neutral-300">Archivo: {selectedPageMedia.name}</p>
                <div className="mt-4">
                  <label className="text-xs font-bold uppercase text-neutral-400 mb-2 block">Brillo del fondo ({bgForm.brightness}%)</label>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={bgForm.brightness}
                    onChange={(e) => setBgForm({...bgForm, brightness: Number(e.target.value)})}
                    className="w-full h-2 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                  />
                </div>
              </div>
            </div>
          ) : (
            <p className="text-sm text-neutral-500">No hay multimedia personalizada para {pageLabels[selectedMediaPage]}. Se muestra el fondo original.</p>
          )}
        </div>
      </div>

      <div className="mb-12 rounded-[2rem] border border-white/10 bg-neutral-900/70 p-6">
        <h2 className="mb-5 text-2xl font-black uppercase italic">Documentos de empleados pendientes</h2>
        {pendingRequests.length === 0 ? (
          <p className="text-neutral-500">No hay solicitudes pendientes.</p>
        ) : (
          <div className="grid gap-5 md:grid-cols-2">
            {pendingRequests.map((request) => (
              <div key={request.id} className="rounded-2xl border border-white/10 bg-black/40 p-5">
                <div className="mb-4 flex items-start gap-4">
                  {request.logoImage ? <img src={request.logoImage} alt={request.workLogoName} className="h-16 w-16 rounded-xl object-cover" /> : <div className="h-16 w-16 rounded-xl bg-white/5" />}
                  <div>
                    <h3 className="font-black text-white">{request.fullName}</h3>
                    <p className="text-sm text-orange-400">{request.workLogoName}</p>
                    <p className="text-sm text-neutral-500">{request.phone}</p>
                  </div>
                </div>
                <p className="text-sm text-neutral-400"><span className="font-bold text-white">Experiencia:</span> {request.experience}</p>
                <p className="mt-2 text-sm text-neutral-400"><span className="font-bold text-white">Motivo:</span> {request.reason}</p>
                <div className="mt-5 flex gap-3">
                  <button onClick={() => acceptRequest(request)} className="inline-flex items-center gap-2 rounded-xl bg-green-500 px-4 py-2 font-black text-black"><UserCheck className="h-4 w-4" /> Aceptar</button>
                  <button onClick={() => rejectRequest(request.id)} className="inline-flex items-center gap-2 rounded-xl bg-red-500 px-4 py-2 font-black text-white"><UserX className="h-4 w-4" /> Rechazar</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="mb-12 grid gap-8 lg:grid-cols-[0.9fr_1.3fr]">
        <form onSubmit={addEmployee} className="rounded-[2rem] border border-white/10 bg-neutral-900/70 p-6">
          <h2 className="mb-5 text-2xl font-black uppercase italic">Agregar empleado</h2>
          <div className="space-y-4">
            <input required value={employeeForm.name} onChange={(e) => setEmployeeForm({ ...employeeForm, name: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Nombre" />
            <input required value={employeeForm.logoName} onChange={(e) => setEmployeeForm({ ...employeeForm, logoName: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Nombre de logo" />
            <input required value={employeeForm.access} onChange={(e) => setEmployeeForm({ ...employeeForm, access: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Acceso" />
            <input required value={employeeForm.password} onChange={(e) => setEmployeeForm({ ...employeeForm, password: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Contraseña" />
            <button className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-3 font-black uppercase text-black"><Plus className="h-4 w-4" /> Agregar empleado</button>
          </div>
        </form>

        <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-neutral-900/70">
          <div className="p-6"><h2 className="text-2xl font-black uppercase italic">Empleados activos</h2></div>
          <div className="overflow-auto">
            <table className="w-full min-w-[760px] text-left">
              <thead className="bg-white/5 text-xs uppercase tracking-widest text-neutral-500"><tr><th className="p-4">N</th><th className="p-4">Nombre</th><th className="p-4">Nombre de logo</th><th className="p-4">Acceso</th><th className="p-4">Contraseña</th><th className="p-4">Activo</th><th className="p-4">Accion</th></tr></thead>
              <tbody className="divide-y divide-white/10">
                 {employees.map((employee, index) => (
                  <tr key={employee.id} className="text-neutral-300">
                    <td className="p-4 text-orange-400 font-black">{index + 1}</td>
                    <td className="p-4 font-bold text-white">{employee.name}</td>
                    <td className="p-4">{employee.logoName}</td>
                    <td className="p-4">{employee.access}</td>
                    <td className="p-4">{employee.password}</td>
                    <td className="p-4">
                      <span className={`rounded-full px-3 py-1 text-xs font-black ${employee.active ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                        {employee.active ? 'Activo' : 'Inactivo'}
                      </span>
                    </td>
                    <td className="p-4 flex gap-2">
                      <button onClick={() => fireEmployee(employee.id)} disabled={!employee.active} className="rounded-xl bg-red-500 px-4 py-2 font-black text-white disabled:cursor-not-allowed disabled:opacity-40">
                        Despedir
                      </button>
                      <button onClick={() => { if(confirm('¿Eliminar empleado definitivamente?')) removeEmployee(employee.id); }} className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30">
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="mb-12 rounded-[2rem] border border-white/10 bg-neutral-900/70 p-6">
        <div className="mb-6 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
          <div>
            <h2 className="text-2xl font-black uppercase italic">Control de horario</h2>
            <p className="mt-2 text-sm text-neutral-400">Activa o libera los cuadros del horario. Cada cuadro activo aparecera como TORNEO en la pagina Horario.</p>
          </div>

          <form onSubmit={submitScheduleSlot} className="flex flex-col gap-3 sm:flex-row">
            <select value={scheduleForm.day} onChange={(e) => setScheduleForm({ ...scheduleForm, day: e.target.value })} className="rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500">
              {scheduleDays.map((day) => <option key={day}>{day}</option>)}
            </select>
            <select value={scheduleForm.time} onChange={(e) => setScheduleForm({ ...scheduleForm, time: e.target.value })} className="rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500">
              {scheduleTimes.map((time) => <option key={time}>{time}</option>)}
            </select>
            <select value={scheduleForm.mode} onChange={(e) => setScheduleForm({ ...scheduleForm, mode: e.target.value as typeof scheduleForm.mode })} className="rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500">
              {scheduleModes.map((mode) => <option key={mode}>{mode}</option>)}
            </select>
            <button className="rounded-xl bg-orange-500 px-5 py-3 font-black uppercase text-black">Guardar horario</button>
          </form>
        </div>

        <div className="overflow-x-auto rounded-xl border border-orange-500/20 bg-[#080812]">
          <table className="w-full min-w-[980px] border-collapse text-center">
            <thead>
              <tr>
                <th className="w-24 border border-black/80 bg-[#242434] p-2 text-sm text-neutral-300" />
                {scheduleDays.map((day) => (
                  <th key={day} className="border border-black/80 bg-gradient-to-b from-[#7a3419] to-[#351206] px-4 py-2 text-sm font-black uppercase tracking-widest text-white">{day}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {scheduleTimes.map((time) => (
                <tr key={time}>
                  <th className="border border-black/80 bg-[#252536] px-3 py-2 text-right text-sm font-black text-neutral-200">{time}</th>
                  {scheduleDays.map((day) => {
                    const activeMode = activeScheduleSlots.get(`${day}-${time}`);
                    const active = Boolean(activeMode);
                    return (
                      <td key={`${day}-${time}`} className="border border-black/80 bg-[#10101a] p-[3px]">
                        <button
                          type="button"
                          onClick={() => toggleScheduleSlot(day, time)}
                          className={`h-7 w-full rounded border px-1 text-[10px] font-black uppercase transition ${active ? 'border-orange-500/70 bg-[#4a1e0e] text-orange-400' : 'border-white/5 bg-transparent text-neutral-700 hover:text-neutral-400'}`}
                        >
                          {active ? activeMode : 'Libre'}
                        </button>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[0.9fr_1.3fr]">
        <form onSubmit={addClan} className="rounded-[2rem] border border-white/10 bg-neutral-900/70 p-6">
          <h2 className="mb-5 text-2xl font-black uppercase italic">Agregar clan</h2>
          <div className="space-y-4">
            <input required type="number" min="1" max="100" value={clanForm.rank} onChange={(e) => setClanForm({ ...clanForm, rank: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="N del 1 al 100" />
            <input required value={clanForm.clanName} onChange={(e) => setClanForm({ ...clanForm, clanName: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Nombre del equipo" />
            <input required value={clanForm.leader} onChange={(e) => setClanForm({ ...clanForm, leader: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Jugador / Lider" />
            <input required type="number" min="0" value={clanForm.rounds} onChange={(e) => setClanForm({ ...clanForm, rounds: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Rondas" />
            <input required type="number" min="0" value={clanForm.kills} onChange={(e) => setClanForm({ ...clanForm, kills: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Kill" />
            <input required type="number" min="0" value={clanForm.booyahs} onChange={(e) => setClanForm({ ...clanForm, booyahs: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Booyahs" />
            <input required type="number" min="0" value={clanForm.points} onChange={(e) => setClanForm({ ...clanForm, points: e.target.value })} className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 outline-none focus:border-orange-500" placeholder="Puntos" />
            <button className="inline-flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-3 font-black uppercase text-black"><Plus className="h-4 w-4" /> Agregar clan</button>
          </div>
        </form>

        <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-neutral-900/70">
          <div className="p-6"><h2 className="text-2xl font-black uppercase italic">Clasificacion Venezuela 1-100</h2></div>
          <div className="max-h-[620px] overflow-auto">
            <table className="w-full min-w-[980px] text-left">
              <thead className="sticky top-0 bg-[#101018] text-xs uppercase tracking-widest text-neutral-500"><tr><th className="p-4">Pos</th><th className="p-4">Equipo</th><th className="p-4">Rondas</th><th className="p-4">Kill</th><th className="p-4">Booyahs</th><th className="p-4">Puntos</th><th className="p-4">Accion</th></tr></thead>
              <tbody className="divide-y divide-white/10">
                {sortedClans.map((clan) => {
                  const isEditing = editingClanId === clan.id;
                  const inputClass = 'w-24 rounded-lg border border-white/10 bg-black/50 px-3 py-2 text-white outline-none focus:border-orange-500';

                  return (
                    <tr key={clan.id} className="text-neutral-300">
                      <td className="p-4 font-black text-orange-400">
                        {isEditing ? <input type="number" min="1" max="100" value={clanEditForm.rank} onChange={(e) => setClanEditForm({ ...clanEditForm, rank: e.target.value })} className={inputClass} /> : clan.rank}
                      </td>
                      <td className="p-4 font-bold text-white">
                        {isEditing ? <input value={clanEditForm.clanName} onChange={(e) => setClanEditForm({ ...clanEditForm, clanName: e.target.value })} className="w-56 rounded-lg border border-white/10 bg-black/50 px-3 py-2 text-white outline-none focus:border-orange-500" /> : clan.clanName}
                      </td>
                      <td className="p-4">
                        {isEditing ? <input type="number" min="0" value={clanEditForm.rounds} onChange={(e) => setClanEditForm({ ...clanEditForm, rounds: e.target.value })} className={inputClass} /> : clan.rounds}
                      </td>
                      <td className="p-4">
                        {isEditing ? <input type="number" min="0" value={clanEditForm.kills} onChange={(e) => setClanEditForm({ ...clanEditForm, kills: e.target.value })} className={inputClass} /> : clan.kills}
                      </td>
                      <td className="p-4">
                        {isEditing ? <input type="number" min="0" value={clanEditForm.booyahs} onChange={(e) => setClanEditForm({ ...clanEditForm, booyahs: e.target.value })} className={inputClass} /> : clan.booyahs}
                      </td>
                      <td className="p-4">
                        {isEditing ? <input type="number" min="0" value={clanEditForm.points} onChange={(e) => setClanEditForm({ ...clanEditForm, points: e.target.value })} className={inputClass} /> : clan.points}
                      </td>
                      <td className="p-4">
                        <div className="flex gap-2">
                          {isEditing ? (
                            <>
                              <button onClick={() => saveEditedClan(clan.id)} className="rounded-xl bg-green-500 px-3 py-2 font-black text-black"><Save className="h-4 w-4" /></button>
                              <button onClick={cancelEditingClan} className="rounded-xl bg-neutral-700 px-3 py-2 font-black text-white"><XCircle className="h-4 w-4" /></button>
                            </>
                          ) : (
                            <>
                              <button onClick={() => startEditingClan(clan)} className="rounded-xl bg-orange-500 px-3 py-2 font-black text-black"><Pencil className="h-4 w-4" /></button>
                              <button onClick={() => deleteClan(clan.id)} className="rounded-xl bg-red-500 px-3 py-2 font-black text-white"><Trash2 className="h-4 w-4" /></button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PageShell>
  );
};

export default AdminPage;