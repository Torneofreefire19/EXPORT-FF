import { useEffect, useMemo, useState } from 'react';
import MediaBackground from '../components/MediaBackground';
import { PageMedia, ScheduleSlot, getPageMedia, getSchedule, scheduleDays, scheduleTimes } from '../lib/storage';

const SchedulePage = () => {
  const [schedule, setSchedule] = useState<ScheduleSlot[]>([]);
  const [pageMedia, setPageMedia] = useState<PageMedia | null>(null);

  useEffect(() => {
    setSchedule(getSchedule());
    setPageMedia(getPageMedia('horario'));
  }, []);

  const activeSlots = useMemo(
    () => new Map(schedule.map((slot) => [`${slot.day}-${slot.time}`, slot.mode ?? 'Batle Royale'])),
    [schedule],
  );

  return (
    <section className="relative min-h-screen overflow-hidden px-4 pb-20 pt-32 text-white sm:px-6 lg:px-8">
      <MediaBackground media={pageMedia} fallbackImage="/images/schedule-bg.jpg" overlayClassName="bg-black/65" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-[#070711]/60 to-black" />

      <div className="relative z-10 mx-auto max-w-7xl">
        <div className="mb-10 max-w-3xl">
          <p className="mb-4 text-xs font-black uppercase tracking-[0.3em] text-orange-400">Calendario oficial</p>
          <h1 className="text-4xl font-black uppercase italic tracking-tight md:text-6xl">Horario</h1>
          <p className="mt-5 text-lg leading-relaxed text-neutral-300">
            Consulta las horas exactas de nuestros torneos. El administrador puede activar o liberar horarios desde su panel.
          </p>
        </div>

        <div className="overflow-hidden rounded-xl border border-orange-500/25 bg-[#080812]/90 shadow-[0_0_35px_rgba(0,0,0,0.55)] backdrop-blur-sm">
        <p className="bg-black/30 px-4 py-3 text-center text-lg font-bold text-neutral-300">
          Consulta las horas exactas de nuestros torneos.
        </p>

        <div className="overflow-x-auto">
          <table className="w-full min-w-[980px] border-collapse text-center">
            <thead>
              <tr>
                <th className="w-24 border border-black/80 bg-[#242434] p-2 text-sm text-neutral-300" />
                {scheduleDays.map((day) => (
                  <th key={day} className="border border-black/80 bg-gradient-to-b from-[#7a3419] to-[#351206] px-4 py-2 text-sm font-black uppercase tracking-widest text-white">
                    {day}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {scheduleTimes.map((time) => (
                <tr key={time}>
                  <th className="border border-black/80 bg-[#252536] px-3 py-2 text-right text-sm font-black text-neutral-200">
                    {time}
                  </th>
                  {scheduleDays.map((day) => {
                    const activeMode = activeSlots.get(`${day}-${time}`);
                    const active = Boolean(activeMode);

                    return (
                      <td key={`${day}-${time}`} className="border border-black/80 bg-[#10101a] p-[3px]">
                        <div
                          className={`h-7 rounded border px-1 text-[10px] font-black uppercase leading-7 sm:text-xs ${
                            active
                              ? 'border-orange-500/70 bg-gradient-to-b from-[#5a2612] to-[#2a1209] text-orange-400 shadow-[inset_0_0_12px_rgba(249,115,22,0.16)]'
                              : 'border-white/5 bg-transparent text-transparent'
                          }`}
                        >
                          {active ? activeMode : 'Libre'}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col items-center justify-center gap-4 border-t border-white/10 bg-[#10101a] px-4 py-3 text-sm font-bold text-neutral-300 sm:flex-row">
          <div className="flex items-center gap-2">
            <span className="h-4 w-4 rounded border border-orange-500/70 bg-[#4a1e0e]" /> Horario Activo (Hay Torneo)
          </div>
          <span className="text-orange-400">Batle Royale</span>
          <span className="text-orange-400">PvP 1vs1</span>
          <span className="text-orange-400">Torneo Clanes</span>
          <div className="flex items-center gap-2">
            <span className="h-4 w-4 rounded border border-white/10 bg-transparent" /> Horario Libre
          </div>
        </div>
        </div>
      </div>
    </section>
  );
};

export default SchedulePage;