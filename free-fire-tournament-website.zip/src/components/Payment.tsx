import { motion } from 'framer-motion';
import { CreditCard, Wallet, Smartphone, ShieldCheck } from 'lucide-react';

const Payment = () => {
  return (
    <section id="pagos" className="py-32 bg-black relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative z-10 bg-neutral-900 border border-white/10 p-8 rounded-[3rem] shadow-2xl"
            >
              <div className="flex items-center gap-4 mb-10">
                <div className="p-4 bg-orange-500 rounded-2xl">
                  <Wallet className="text-black h-8 w-8" />
                </div>
                <h2 className="text-3xl font-black uppercase italic">Tu Billetera FF</h2>
              </div>
              
              <div className="space-y-6">
                {[
                  { icon: Smartphone, title: "Pago Móvil", desc: "Aceptamos todos los bancos de Venezuela." },
                  { icon: ShieldCheck, title: "Seguro y Privado", desc: "Tus datos están encriptados y seguros." },
                  { icon: CreditCard, title: "Sin Comisiones", desc: "Recibes el monto exacto de tus kills." },
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-orange-500/30 transition-colors">
                    <item.icon className="h-6 w-6 text-orange-400 shrink-0" />
                    <div>
                      <h4 className="font-bold text-white">{item.title}</h4>
                      <p className="text-neutral-500 text-sm">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
            <div className="absolute -inset-4 bg-orange-500/20 blur-3xl rounded-full opacity-50" />
          </div>

          <div>
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <h3 className="text-5xl font-black uppercase italic leading-tight">
                Cobros <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">
                  Sin Complicaciones
                </span>
              </h3>
              <p className="text-neutral-400 text-lg leading-relaxed">
                En <span className="text-white font-bold">EXPORT FF</span> sabemos que quieres tu dinero rápido. 
                Por eso hemos implementado el sistema de Pago Móvil más eficiente del país.
              </p>
              
              <div className="p-8 bg-gradient-to-br from-orange-500/10 to-orange-600/10 rounded-3xl border border-orange-500/20">
                <p className="text-orange-400 font-bold uppercase tracking-widest text-sm mb-4">Proceso de Pago</p>
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-4 text-white font-medium">
                    <span className="w-8 h-8 rounded-full bg-orange-500 text-black flex items-center justify-center font-bold">1</span>
                    Terminas el Torneo
                  </div>
                  <div className="flex items-center gap-4 text-white font-medium">
                    <span className="w-8 h-8 rounded-full bg-orange-500 text-black flex items-center justify-center font-bold">2</span>
                    Validamos tus Kills / Victoria
                  </div>
                  <div className="flex items-center gap-4 text-white font-medium">
                    <span className="w-8 h-8 rounded-full bg-orange-500 text-black flex items-center justify-center font-bold">3</span>
                    Recibe Pago Movil en 5 minutos
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Payment;
