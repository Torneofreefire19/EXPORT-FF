import { useAppContext, PageKey } from '../context/AppContext';

function getYouTubeId(url: string): string {
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? match[2] : url;
}

export default function PageBackground({ page, children }: { page: PageKey; children: React.ReactNode }) {
  const { pageBackgrounds } = useAppContext();
  const bg = pageBackgrounds[page];

  if (!bg || !bg.url) {
    return <>{children}</>;
  }

  return (
    <div className="relative min-h-screen">
      {bg.type === 'image' ? (
        <div className="fixed inset-0 bg-cover bg-center bg-no-repeat -z-10" style={{ backgroundImage: `url('${bg.url}')`, filter: `brightness(${bg.brightness}%)` }} />
      ) : bg.type === 'youtube' ? (
        <div className="fixed inset-0 overflow-hidden -z-10">
          <iframe
            src={`https://www.youtube.com/embed/${getYouTubeId(bg.url)}?autoplay=1&mute=${bg.muted ? 1 : 0}&loop=1&controls=0&playlist=${getYouTubeId(bg.url)}&showinfo=0&modestbranding=1`}
            className="absolute top-1/2 left-1/2 min-w-[150%] min-h-[150%] -translate-x-1/2 -translate-y-1/2 w-[150%] h-[150%]"
            allow="autoplay; encrypted-media"
            allowFullScreen
            style={{ pointerEvents: 'none', filter: `brightness(${bg.brightness}%)` }}
          />
        </div>
      ) : (
        <video
          src={bg.url}
          className="fixed inset-0 w-full h-full object-cover -z-10"
          autoPlay
          loop
          playsInline
          muted={bg.muted}
          style={{ filter: `brightness(${bg.brightness}%)` }}
        />
      )}
      <div className="absolute inset-0 bg-black/70 -z-10" />
      {children}
    </div>
  );
}
