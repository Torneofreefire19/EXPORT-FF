import { motion } from 'framer-motion';
import { Trophy, Medal, Award } from 'lucide-react';

const Ranking = () => {
  const topPlayers = [
    { name: "Slayer_FF", kills: 142, earnings: "$142", rank: 1, color: "text-yellow-400" },
    { name: "GhostRider", kills: 118, earnings: "$118", rank: 2, color: "text-slate-300" },
    { name: "NovaQueen", kills: 95, earnings: "$95", rank: 3, color: "text-orange-400" },
    { name: "Venom_BR", kills: 88, earnings: "$88", rank: 4, color: "text-neutral-400" },
    { name: "ZestyPlayer", kills: 76, earnings: "$76", rank: 5, color: "text-neutral-400" },
  ];

  return (
    <section id="ranking" className="py-32 bg-[#080808] text-white relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-cyan-500/5 blur-[100px] rounded-full translate-x-1/2" />
      
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-black uppercase italic mb-4">Hall of <span className="text-orange-400">Fame</span></h2>
          <p className="text-neutral-500">Los jugadores que más han monetizado sus habilidades este mes.</p>
        </div>

        <div className="bg-neutral-900/50 border border-white/10 rounded-[2.5rem] overflow-hidden backdrop-blur-sm">
          <div className="grid grid-cols-4 p-6 border-b border-white/10 text-xs font-black uppercase tracking-widest text-neutral-500">
            <div className="col-span-1">Rango</div>
            <div className="col-span-1">Jugador</div>
            <div className="col-span-1 text-center">Kills</div>
            <div className="col-span-1 text-right">Ganancias</div>
          </div>
          
          <div className="divide-y divide-white/5">
            {topPlayers.map((player, i) => (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                key={i} 
                className="grid grid-cols-4 p-6 items-center hover:bg-white/5 transition-colors group"
              >
                <div className={`col-span-1 font-black text-2xl ${player.color} flex items-center gap-2`}>
                  {player.rank === 1 && <Trophy className="h-5 w-5" />}
                  {player.rank === 2 && <Medal className="h-5 w-5" />}
                  {player.rank === 3 && <Award className="h-5 w-5" />}
                  #{player.rank}
                </div>
                <div className="col-span-1 font-bold text-lg group-hover:text-cyan-400 transition-colors">{player.name}</div>
                <div className="col-span-1 text-center font-mono text-neutral-400">{player.kills}</div>
                <div className="col-span-1 text-right font-mono font-bold text-orange-400">{player.earnings}</div>
              </motion.div>
            ))}
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-neutral-500 text-sm italic">
            * Los rankings se actualizan cada 24 horas basados en torneos validados.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Ranking;
