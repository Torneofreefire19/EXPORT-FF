import { Trophy } from 'lucide-react';

const TikTokIcon = () => (
  <svg className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M16.6 3c.3 2.1 1.6 3.8 3.6 4.3v3.1a7.6 7.6 0 0 1-3.7-1.1v6.2A5.5 5.5 0 1 1 11 10v3.2a2.3 2.3 0 1 0 2.3 2.3V3h3.3Z" />
  </svg>
);

const YouTubeIcon = () => (
  <svg className="h-7 w-7" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M21.6 7.2s-.2-1.5-.8-2.1c-.8-.8-1.7-.8-2.1-.9C15.8 4 12 4 12 4s-3.8 0-6.7.2c-.4.1-1.3.1-2.1.9-.6.6-.8 2.1-.8 2.1S2.2 9 2.2 10.8v1.7c0 1.8.2 3.6.2 3.6s.2 1.5.8 2.1c.8.8 1.9.8 2.4.9 1.7.2 6.4.2 6.4.2s3.8 0 6.7-.2c.4-.1 1.3-.1 2.1-.9.6-.6.8-2.1.8-2.1s.2-1.8.2-3.6v-1.7c0-1.8-.2-3.6-.2-3.6ZM10.1 14.8V8.6l5.8 3.1-5.8 3.1Z" />
  </svg>
);

const Footer = () => {
  return (
    <footer className="bg-black border-t border-white/5 py-20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-orange-500 p-2 rounded-lg">
                <Trophy className="h-5 w-5 text-black" />
              </div>
              <span className="text-2xl font-black tracking-tighter uppercase italic">
                EXPORT <span className="text-orange-400">FF</span>
              </span>
            </div>
            <p className="text-neutral-500 max-w-sm leading-relaxed">
              La plataforma líder en torneos competitivos de Free Fire en Venezuela. 
              Llevamos la competencia al siguiente nivel con premios reales y pagos instantáneos.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold uppercase tracking-widest text-white mb-6">Enlaces</h4>
            <ul className="space-y-4 text-neutral-500 text-sm">
               <li><a href="#/inicio" className="hover:text-orange-400 transition-colors">Inicio</a></li>
               <li><a href="#/inscripcion" className="hover:text-orange-400 transition-colors">Inscripción</a></li>
               <li><a href="#/clasificacion" className="hover:text-orange-400 transition-colors">Ranking</a></li>
               <li><a href="#/administrador" className="hover:text-orange-400 transition-colors">Administrador</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold uppercase tracking-widest text-white mb-6">Redes Sociales</h4>
            <div className="space-y-3">
              <a href="https://www.tiktok.com/@Torneofreefire19" target="_blank" rel="noreferrer" className="flex items-center gap-3 text-neutral-400 transition-colors hover:text-orange-400">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-neutral-900 text-white transition-all hover:bg-orange-500 hover:text-black">
                  <TikTokIcon />
                </span>
                <span className="font-black tracking-wide">@Torneofreefire19</span>
              </a>
              <a href="https://www.youtube.com/@Torneofreefire19" target="_blank" rel="noreferrer" className="flex items-center gap-3 text-neutral-400 transition-colors hover:text-orange-400">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-neutral-900 text-red-500 transition-all hover:bg-orange-500 hover:text-black">
                  <YouTubeIcon />
                </span>
                <span className="font-black tracking-wide">@Torneofreefire19</span>
              </a>
            </div>
          </div>
        </div>
        
        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-neutral-600 text-xs font-bold uppercase tracking-widest">
          <p>&copy; {new Date().getFullYear()} Torneo Export FF. Todos los derechos reservados.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Términos</a>
            <a href="#" className="hover:text-white transition-colors">Privacidad</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
