import { Menu, X } from 'lucide-react';
import { useEffect, useState } from 'react';

const menuItems = [
  { name: 'Inicio', href: '#/inicio' },
  { name: 'Recarga de Diamante', href: '#/diamantes' },
  { name: 'Compra y Venta de Cuenta', href: '#/cuentas' },
  { name: 'Inscripción', href: '#/inscripcion' },
  { name: 'Detalles', href: '#/detalles' },
  { name: 'Horario', href: '#/horario' },
  { name: 'Tabla de Clasificación de Clanes', href: '#/clasificacion' },
  { name: 'Solicitar Trabajo', href: '#/solicitar-trabajo' },
  { name: 'Empleado', href: '#/empleado' },
  { name: 'Administrador', href: '#/administrador' },
];

const TikTokIcon = () => (
  <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M16.6 3c.3 2.1 1.6 3.8 3.6 4.3v3.1a7.6 7.6 0 0 1-3.7-1.1v6.2A5.5 5.5 0 1 1 11 10v3.2a2.3 2.3 0 1 0 2.3 2.3V3h3.3Z" />
  </svg>
);

const YouTubeIcon = () => (
  <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M21.6 7.2s-.2-1.5-.8-2.1c-.8-.8-1.7-.8-2.1-.9C15.8 4 12 4 12 4s-3.8 0-6.7.2c-.4.1-1.3.1-2.1.9-.6.6-.8 2.1-.8 2.1S2.2 9 2.2 10.8v1.7c0 1.8.2 3.6.2 3.6s.2 1.5.8 2.1c.8.8 1.9.8 2.4.9 1.7.2 6.4.2 6.4.2s3.8 0 6.7-.2c.4-.1 1.3-.1 2.1-.9.6-.6.8-2.1.8-2.1s.2-1.8.2-3.6v-1.7c0-1.8-.2-3.6-.2-3.6ZM10.1 14.8V8.6l5.8 3.1-5.8 3.1Z" />
  </svg>
);

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activePath, setActivePath] = useState(window.location.hash || '#/inicio');

  useEffect(() => {
    const updateActivePath = () => setActivePath(window.location.hash || '#/inicio');
    window.addEventListener('hashchange', updateActivePath);
    return () => window.removeEventListener('hashchange', updateActivePath);
  }, []);

  return (
    <>
      <nav className="fixed top-0 w-full z-40 bg-transparent text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-20 items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsOpen(true)}
                className="flex items-center justify-center rounded-lg p-2 text-white transition-colors hover:bg-white/10"
                aria-label="Abrir menu"
              >
                <Menu className="h-7 w-7" />
              </button>
              <a href="#/inicio" className="text-xl font-black uppercase tracking-tighter text-white md:text-2xl">
                Torneo<span className="text-red-500">Export</span>FF
              </a>
            </div>
            <div />
          </div>
        </div>
      </nav>

      <div className={`fixed inset-0 z-50 transition-all duration-300 ${isOpen ? 'visible' : 'invisible'}`}>
        <div
          className={`absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0'}`}
          onClick={() => setIsOpen(false)}
        />

        <aside
          className={`absolute left-0 top-0 flex h-full w-[306px] flex-col bg-[#07070e] text-white shadow-[10px_0_35px_rgba(0,0,0,0.7)] transition-transform duration-300 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
        >
          <div className="flex items-center justify-between px-5 pb-6 pt-5">
            <a href="#/inicio" onClick={() => setIsOpen(false)} className="text-lg font-black uppercase tracking-tighter text-white">
              Torneo<span className="text-red-500">Export</span>FF
            </a>
            <button
              onClick={() => setIsOpen(false)}
              className="text-neutral-400 transition-colors hover:text-white"
              aria-label="Cerrar menu"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto px-4 pb-4 [scrollbar-color:#ef4444_#10131c] [scrollbar-width:thin] [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-red-600 [&::-webkit-scrollbar-track]:rounded-full [&::-webkit-scrollbar-track]:bg-[#10131c]">
            {menuItems.map((item) => {
              const active = activePath === item.href || (activePath === '' && item.href === '#/inicio');

              return (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsOpen(false)}
                  className={`block rounded-md px-4 py-3 text-[15px] font-bold transition-colors ${
                    active
                      ? 'bg-red-950/70 text-red-300 shadow-[inset_0_0_0_1px_rgba(239,68,68,0.12)]'
                      : 'text-neutral-300 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  {item.name}
                </a>
              );
            })}
          </div>

          <div className="border-t border-white/10 px-5 py-6">
            <div className="flex items-center gap-3">
              <a
                href="https://www.tiktok.com/@Torneofreefire19"
                target="_blank"
                rel="noreferrer"
                className="flex h-11 w-11 items-center justify-center rounded-full bg-[#10131c] text-white transition hover:bg-red-600"
                aria-label="TikTok @Torneofreefire19"
              >
                <TikTokIcon />
              </a>
              <a
                href="https://www.youtube.com/@Torneofreefire19"
                target="_blank"
                rel="noreferrer"
                className="flex h-11 w-11 items-center justify-center rounded-full bg-[#10131c] text-white transition hover:bg-red-600"
                aria-label="YouTube @Torneofreefire19"
              >
                <YouTubeIcon />
              </a>
              <span className="text-sm font-bold text-neutral-500">@Torneofreefire19</span>
            </div>
          </div>
        </aside>
      </div>
    </>
  );
};

export default Navbar;