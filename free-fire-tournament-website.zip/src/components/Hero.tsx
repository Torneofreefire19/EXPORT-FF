import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Circle, Play } from 'lucide-react';
import MediaBackground from './MediaBackground';
import { getPageMedia, PageMedia } from '../lib/storage';
import { useAppContext } from '../context/AppContext';

const TikTokIcon = () => (
  <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M16.6 3c.3 2.1 1.6 3.8 3.6 4.3v3.1a7.6 7.6 0 0 1-3.7-1.1v6.2A5.5 5.5 0 1 1 11 10v3.2a2.3 2.3 0 1 0 2.3 2.3V3h3.3Z" />
  </svg>
);

const YouTubeIcon = () => (
  <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M21.6 7.2s-.2-1.5-.8-2.1c-.8-.8-1.7-.8-2.1-.9C15.8 4 12 4 12 4s-3.8 0-6.7.2c-.4.1-1.3.1-2.1.9-.6.6-.8 2.1-.8 2.1S2.2 9 2.2 10.8v1.7c0 1.8.2 3.6.2 3.6s.2 1.5.8 2.1c.8.8 1.9.8 2.4.9 1.7.2 6.4.2 6.4.2s3.8 0 6.7-.2c.4-.1 1.3-.1 2.1-.9.6-.6.8-2.1.8-2.1s.2-1.8.2-3.6v-1.7c0-1.8-.2-3.6-.2-3.6ZM10.1 14.8V8.6l5.8 3.1-5.8 3.1Z" />
  </svg>
);

const Hero = () => {
  const [homeMedia, setHomeMedia] = useState<PageMedia | null>(null);
  const { seasonInfo } = useAppContext();

  useEffect(() => {
    setHomeMedia(getPageMedia('inicio'));
  }, []);

  return (
    <section id="inicio" className="relative flex min-h-screen items-center justify-center overflow-hidden text-white">
      <MediaBackground media={homeMedia} fallbackImage="/images/hero-bg.jpg" overlayClassName="bg-black/68" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(239,68,68,0.18),transparent_34%),linear-gradient(to_bottom,rgba(0,0,0,0.55),rgba(0,0,0,0.2),rgba(0,0,0,0.9))]" />

      <div className="absolute right-5 top-6 z-30 flex items-center gap-3">
        <a
          href="https://www.tiktok.com/@Torneofreefire19"
          target="_blank"
          rel="noreferrer"
          className="flex h-11 w-11 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur transition hover:bg-red-600"
          aria-label="TikTok @Torneofreefire19"
        >
          <TikTokIcon />
        </a>
        <a
          href="https://www.youtube.com/@Torneofreefire19"
          target="_blank"
          rel="noreferrer"
          className="flex h-11 w-11 items-center justify-center rounded-full bg-black/60 text-white backdrop-blur transition hover:bg-red-600"
          aria-label="YouTube @Torneofreefire19"
        >
          <YouTubeIcon />
        </a>
      </div>

      <div className="absolute left-4 top-24 z-10 hidden items-center gap-2 text-xs font-black uppercase tracking-widest text-white/80 md:flex">
        <span className="text-white">Torneo</span><span className="text-red-500">Export</span><span>FF</span>
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-4 pt-20 text-center sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="flex flex-col items-center"
        >
          {seasonInfo.active && (
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-red-500/25 bg-red-500/10 px-4 py-2 text-[11px] font-black uppercase tracking-widest text-red-400">
              <Circle className="h-2 w-2 fill-current" /> {seasonInfo.text}
            </div>
          )}

          <h1 className="text-6xl font-black uppercase leading-[0.85] tracking-tighter md:text-8xl lg:text-9xl">
            Torneo
          </h1>
          <h2 className="mt-3 text-5xl font-black uppercase leading-[0.9] tracking-tighter md:text-7xl lg:text-8xl">
            <span className="text-red-600 drop-shadow-[0_0_28px_rgba(220,38,38,0.7)]">Export</span>{' '}
            <span className="text-white">FF</span>
          </h2>

          <p className="mt-7 text-xl font-black uppercase tracking-wide text-white md:text-2xl">
            Gana dinero real
          </p>
          <p className="mt-5 max-w-xl text-sm leading-relaxed text-neutral-300 md:text-base">
            Tres modos de juego para ganar dinero con Free Fire. Cada kill, cada victoria y cada clan cuenta. Recibe Pago Movil en 5 minutos.
          </p>

          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a
              href="#/inscripcion"
              className="group inline-flex items-center gap-2 rounded-full bg-red-600 px-7 py-4 text-xs font-black uppercase tracking-widest text-white transition-all hover:bg-red-500 hover:shadow-[0_0_30px_rgba(220,38,38,0.45)]"
            >
              Inscribete ahora <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#/detalles"
              className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-7 py-4 text-xs font-black uppercase tracking-widest text-white backdrop-blur-sm transition-all hover:bg-white/10"
            >
              <Play className="h-4 w-4" /> Como funciona
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;