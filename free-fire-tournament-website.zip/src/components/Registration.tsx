import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Target, Swords, Users } from 'lucide-react';
import MediaBackground from './MediaBackground';
import { getPageMedia, getWhatsAppLinks, PageMedia, WhatsAppLinks } from '../lib/storage';

const Registration = () => {
  const [pageMedia, setPageMedia] = useState<PageMedia | null>(null);
  const [links, setLinks] = useState<WhatsAppLinks>(getWhatsAppLinks());

  useEffect(() => {
    setPageMedia(getPageMedia('inscripcion'));
    setLinks(getWhatsAppLinks());
  }, []);

  const modes = [
    {
      label: 'Modo 1',
      title: 'Batle Royale',
      href: links.battleRoyale.url,
      image: links.battleRoyale.image,
      icon: Target,
      description:
        'Ganas $1 por cada kill. No importa si ganas o pierdes la partida, lo importante son las kills. Si haces 5 kills, ganas $5 directamente a tu Pago Movil. Los pagos se realizan al final de la partida.',
    },
    {
      label: 'Modo 2',
      title: 'PVP 1vs1',
      href: links.pvp.url,
      image: links.pvp.image,
      icon: Swords,
      description:
        'Dos jugadores se enfrentan y el jugador que gane se lleva su dinero. Si quiere seguir jugando contra otros jugadores, es su decision: puede seguir ganando dinero o retirar. Si decide continuar en PVP, se descuenta lo que gano para entrar a la siguiente partida, pero puede ganar mas si vuelve a ganar.',
    },
    {
      label: 'Modo 3',
      title: 'Torneo de Clan',
      href: links.clanes.url,
      image: links.clanes.image,
      icon: Users,
      description:
        'Todos los clanes pueden participar. El clan que gane sera anunciado en toda Venezuela como campeon de clanes y tambien recibira un premio especial por su victoria.',
    },
  ];

  return (
    <section id="registro" className="relative min-h-screen overflow-hidden bg-[#050505] py-32 text-white">
      <MediaBackground media={pageMedia} fallbackImage="/images/hero-bg.jpg" overlayClassName="bg-black/78" />

      <div className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        <div className="mb-14 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-5 inline-flex items-center gap-2 rounded-full border border-green-500/25 bg-green-500/10 px-4 py-2 text-xs font-black uppercase tracking-widest text-green-400"
          >
            <MessageCircle className="h-4 w-4" /> Enlaces de WhatsApp
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 }}
            className="text-5xl font-black uppercase italic tracking-tight md:text-7xl"
          >
            Inscripción
          </motion.h1>
          <p className="mx-auto mt-5 max-w-2xl text-neutral-400">
            Selecciona el modo donde quieres participar y entra directamente al grupo oficial de WhatsApp.
          </p>
        </div>

        <div className="mx-auto grid max-w-3xl gap-6">
          {modes.map((mode, index) => {
            const Icon = mode.icon;
            return (
              <motion.a
                key={mode.title}
                href={mode.href}
                target="_blank"
                rel="noreferrer"
                initial={{ opacity: 0, y: 26 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="group overflow-hidden rounded-[2rem] border border-white/10 bg-neutral-950/80 text-left backdrop-blur-xl transition hover:-translate-y-1 hover:border-green-500/45 hover:shadow-[0_0_40px_rgba(34,197,94,0.16)]"
              >
                <div className="relative h-48 overflow-hidden">
                  <img src={mode.image} alt={mode.title} className="h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-black/40" />
                  <div className="absolute bottom-4 left-4 flex h-12 w-12 items-center justify-center rounded-xl bg-green-500 text-black">
                    <Icon className="h-7 w-7" />
                  </div>
                </div>
                <div className="p-6 flex flex-col flex-1">
                  <p className="text-xs font-bold uppercase tracking-widest text-green-500">{mode.label}</p>
                  <h2 className="mt-1 text-2xl font-black uppercase italic text-white">{mode.title}</h2>
                  <p className="mt-3 text-sm leading-relaxed text-neutral-400 flex-1">{mode.description}</p>
                  <div className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-green-500 px-5 py-4 text-sm font-black uppercase tracking-widest text-black transition hover:bg-green-400">
                    <MessageCircle className="h-5 w-5" /> Entrar al WhatsApp
                  </div>
                </div>
              </motion.a>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Registration;