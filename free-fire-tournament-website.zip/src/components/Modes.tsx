import { motion } from 'framer-motion';
import { Target, Swords, Users, TrendingUp, CheckCircle2 } from 'lucide-react';

const ModeCard = ({ icon: Icon, title, prize, description, details, color }: any) => {
  return (
    <motion.div 
      whileHover={{ y: -10 }}
      className="group relative bg-neutral-900/50 border border-white/10 p-1 rounded-[2rem] overflow-hidden"
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-0 group-hover:opacity-10 transition-opacity`} />
      
      <div className="bg-neutral-900 p-8 rounded-[1.9rem] h-full relative z-10">
        <div className={`p-4 rounded-2xl w-fit mb-6 bg-gradient-to-br ${color} text-white`}>
          <Icon className="h-8 w-8" />
        </div>
        
        <h3 className="text-3xl font-black uppercase italic text-white mb-2">{title}</h3>
        <div className="text-orange-400 font-bold text-2xl mb-6 flex items-center gap-2">
          <TrendingUp className="h-6 w-6" /> {prize}
        </div>
        
        <p className="text-neutral-400 mb-8 leading-relaxed">
          {description}
        </p>
        
        <div className="space-y-3">
          {details.map((detail: string, idx: number) => (
            <div key={idx} className="flex items-center gap-3 text-sm text-neutral-300">
              <CheckCircle2 className="h-4 w-4 text-orange-500 shrink-0" />
              {detail}
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

const Modes = () => {
  const modes = [
    {
      icon: Target,
      title: "Battle Royale",
      prize: "$1 p/ Kill",
      color: "from-orange-500 to-orange-600",
      description: "La modalidad donde el caos se traduce en dinero. Elimina a tus enemigos y suma dólares sin importar el puesto final.",
      details: [
        "1 Kill = $1 USD garantizado",
        "No importa si ganas o pierdes",
        "Pagos directos vía Pago Móvil",
        "Sin límite de kills por partida"
      ]
    },
    {
      icon: Swords,
      title: "PvP 1vs1",
      prize: "Premio Winner",
      color: "from-purple-500 to-indigo-600",
      description: "Duelos intensos de habilidad pura. Gana la partida y toma el control total de tus ganancias.",
      details: [
        "El ganador reclama el premio total",
        "Opción de Retiro Instantáneo",
        "Opción de Acumular Ganancias",
        "Tú decides cuándo cobrar"
      ]
    },
    {
      icon: Users,
      title: "Clan War",
      prize: "Gloria Nacional",
      color: "from-rose-500 to-red-600",
      description: "El desafío definitivo. Forma equipo con tu clan y lucha por el reconocimiento más alto de Venezuela.",
      details: [
        "Torneo especial por equipos",
        "Título: 'Mejor Clan de Venezuela'",
        "Premios acumulados para el equipo",
        "Final transmitida en streaming"
      ]
    }
  ];

  return (
    <section id="modos" className="py-32 bg-black relative">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-orange-500/50 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-block px-4 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-bold uppercase tracking-widest mb-4"
          >
            Sistemas de Ganancia
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-black uppercase italic text-white mb-6"
          >
            Elige tu <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Camino al Éxito</span>
          </motion.h2>
          <p className="text-neutral-500 max-w-2xl mx-auto text-lg">
            Tres modalidades diseñadas para diferentes tipos de jugadores. Desde el asesino solitario hasta el líder de clan.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {modes.map((mode, index) => (
            <ModeCard key={index} {...mode} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Modes;
