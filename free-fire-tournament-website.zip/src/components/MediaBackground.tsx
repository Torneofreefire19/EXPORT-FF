import { Volume2, VolumeX } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { PageMedia } from '../lib/storage';

type MediaBackgroundProps = {
  media: PageMedia | null;
  fallbackImage: string;
  overlayClassName?: string;
};

const getYouTubeId = (src: string) => {
  const patterns = [/embed\/([^?&]+)/, /watch\?v=([^&]+)/, /youtu\.be\/([^?&]+)/, /shorts\/([^?&]+)/];
  return patterns.map((pattern) => src.match(pattern)?.[1]).find(Boolean) ?? '';
};

const MediaBackground = ({ media, fallbackImage, overlayClassName = 'bg-black/65' }: MediaBackgroundProps) => {
  const [muted, setMuted] = useState(true);
  const youtubeId = useMemo(() => (media?.type === 'youtube' ? getYouTubeId(media.src) : ''), [media]);

  const youtubeSrc = youtubeId
    ? `https://www.youtube.com/embed/${youtubeId}?autoplay=1&loop=1&playlist=${youtubeId}&controls=0&rel=0&modestbranding=1&iv_load_policy=3&disablekb=1&fs=0&playsinline=1&mute=${muted ? 1 : 0}`
    : '';

  return (
    <>
      {media?.type === 'video' ? (
        <video className="absolute inset-0 h-full w-full object-cover" style={{ filter: `brightness(${media.brightness}%)` }} src={media.src} autoPlay loop playsInline muted={muted} controls={false} />
      ) : media?.type === 'youtube' && youtubeSrc ? (
        <iframe
          className="pointer-events-none absolute left-1/2 top-1/2 h-[120vh] w-[213vh] min-h-full min-w-full -translate-x-1/2 -translate-y-1/2"
          style={{ filter: `brightness(${media.brightness}%)` }}
          src={youtubeSrc}
          title={media.name}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
      ) : (
        <div className="absolute inset-0 bg-cover bg-center bg-no-repeat" style={{ backgroundImage: `url('${media?.src ?? fallbackImage}')`, filter: `brightness(${media?.brightness ?? 100}%)` }} />
      )}

      <div className={`pointer-events-none absolute inset-0 ${overlayClassName}`} />

      {(media?.type === 'video' || media?.type === 'youtube') && (
        <button
          type="button"
          onClick={() => setMuted((current) => !current)}
          className="absolute bottom-5 right-5 z-30 flex h-12 w-12 items-center justify-center rounded-full border border-white/25 bg-black/45 text-white shadow-[0_0_18px_rgba(0,0,0,0.45)] backdrop-blur-md transition hover:border-red-400 hover:bg-red-600/80"
          aria-label={muted ? 'Activar sonido' : 'Apagar sonido'}
        >
          {muted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
        </button>
      )}
    </>
  );
};

export default MediaBackground;