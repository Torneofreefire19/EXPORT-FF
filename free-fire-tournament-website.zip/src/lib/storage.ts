export type WorkRequest = {
  id: string;
  fullName: string;
  phone: string;
  workLogoName: string;
  logoImage: string;
  experience: string;
  reason: string;
  status: 'pendiente' | 'aceptado' | 'rechazado';
  createdAt: string;
};

export type Employee = {
  id: string;
  name: string;
  logoName: string;
  access: string;
  password: string;
  active: boolean;
  phone: string;
};

export type ClanRank = {
  id: string;
  rank: number;
  clanName: string;
  leader: string;
  rounds: number;
  kills: number;
  booyahs: number;
  points: number;
};

export type AccountListing = {
  id: string;
  sellerName: string;
  phone: string;
  logo: string;
  logoName: string;
  price: string;
  description: string;
  media: { type: 'image' | 'video', src: string }[];
};

export type DiamondOffer = {
  id: string;
  sellerName: string;
  sellerAccess: string;
  logo: string;
  logoName: string;
  phone: string;
  offers: { amount: string; price: string }[];
};

export type ScheduleSlot = {
  id: string;
  day: string;
  time: string;
  mode: ScheduleMode;
};

export type ScheduleMode = 'Batle Royale' | 'PvP 1vs1' | 'T.clanes';

export type HomeMedia = {
  type: 'image' | 'video' | 'youtube';
  src: string;
  name: string;
  updatedAt: string;
  brightness: number;
};

export type PageKey = 'inicio' | 'inscripcion' | 'horario' | 'clasificacion' | 'diamantes' | 'cuentas';
export type PageMedia = HomeMedia;

export type WhatsAppEntry = {
  url: string;
  image: string;
};

export type WhatsAppLinks = {
  battleRoyale: WhatsAppEntry;
  pvp: WhatsAppEntry;
  clanes: WhatsAppEntry;
};

export const scheduleDays = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo'];
export const scheduleTimes = ['3:00 PM', '4:00 PM', '5:00 PM', '6:00 PM', '7:00 PM', '8:00 PM', '9:00 PM', '10:00 PM', '11:00 PM'];
export const scheduleModes: ScheduleMode[] = ['Batle Royale', 'PvP 1vs1', 'T.clanes'];

const getDefaultScheduleMode = (day: string): ScheduleMode => {
  if (['Sabado', 'Domingo'].includes(day)) return 'T.clanes';
  if (day === 'Viernes') return 'PvP 1vs1';
  return 'Batle Royale';
};

const normalizeSchedule = (slots: ScheduleSlot[]): ScheduleSlot[] =>
  slots.map((slot) => {
    const rawMode = (slot as unknown as { mode?: string }).mode;
    const mode = rawMode === 'Torneo Clanes'
      ? 'T.clanes'
      : scheduleModes.includes(rawMode as ScheduleMode)
        ? (rawMode as ScheduleMode)
        : getDefaultScheduleMode(slot.day);

    return { ...slot, mode };
  });

const defaultSchedule = (): ScheduleSlot[] => {
  const slots: ScheduleSlot[] = [];

  scheduleDays.forEach((day) => {
    scheduleTimes.forEach((time) => {
      const weekdayActive = ['Lunes', 'Martes', 'Miercoles', 'Jueves'].includes(day) && ['6:00 PM', '7:00 PM', '8:00 PM', '9:00 PM', '10:00 PM'].includes(time);
      const fridayActive = day === 'Viernes' && ['5:00 PM', '6:00 PM', '7:00 PM', '8:00 PM', '9:00 PM', '10:00 PM', '11:00 PM'].includes(time);
      const weekendActive = ['Sabado', 'Domingo'].includes(day);

      if (weekdayActive || fridayActive || weekendActive) {
        slots.push({ id: `${day}-${time}`, day, time, mode: getDefaultScheduleMode(day) });
      }
    });
  });

  return slots;
};

const readList = <T,>(key: string, fallback: T[]): T[] => {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T[]) : fallback;
  } catch {
    return fallback;
  }
};

const writeList = <T,>(key: string, value: T[]) => {
  localStorage.setItem(key, JSON.stringify(value));
};

const readValue = <T,>(key: string): T | null => {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : null;
  } catch {
    return null;
  }
};

const writeValue = <T,>(key: string, value: T) => {
  localStorage.setItem(key, JSON.stringify(value));
};

export const storageKeys = {
  requests: 'torneo-export-ff-work-requests',
  employees: 'torneo-export-ff-employees',
  clans: 'torneo-export-ff-clans',
  schedule: 'torneo-export-ff-schedule',
  homeMedia: 'torneo-export-ff-home-media',
  pageMedia: 'torneo-export-ff-page-media',
  whatsappLinks: 'torneo-export-ff-whatsapp-links',
  adminCreds: 'torneo-export-ff-admin-creds',
};

export const defaultWhatsAppLinks: WhatsAppLinks = {
  battleRoyale: {
    url: 'https://chat.whatsapp.com/REEMPLAZA_BATTLE_ROYALE',
    image: '/images/battle-royale-bg.jpg',
  },
  pvp: {
    url: 'https://chat.whatsapp.com/REEMPLAZA_PVP_1VS1',
    image: '/images/pvp-1v1-bg.jpg',
  },
  clanes: {
    url: 'https://chat.whatsapp.com/REEMPLAZA_TORNEO_CLANES',
    image: '/images/torneo-clan-bg.jpg',
  },
};

export const getRequests = () => readList<WorkRequest>(storageKeys.requests, []);
export const saveRequests = (requests: WorkRequest[]) => writeList(storageKeys.requests, requests);

export const getEmployees = () =>
  readList<Employee>(storageKeys.employees, [
    { id: 'emp-1', name: 'Carlos Admin', logoName: 'Export FF', access: 'admin-export', password: '123456', active: true, phone: '0000000000' },
  ]);
export const saveEmployees = (employees: Employee[]) => writeList(storageKeys.employees, employees);

export const getClans = () =>
  readList<ClanRank>(storageKeys.clans, [
    { id: 'clan-1', rank: 1, clanName: 'Venezuela Elite', leader: 'DragonVzla', rounds: 18, kills: 142, booyahs: 8, points: 9850 },
    { id: 'clan-2', rank: 2, clanName: 'Caracas Kings', leader: 'Slayer_FF', rounds: 18, kills: 128, booyahs: 6, points: 9410 },
    { id: 'clan-3', rank: 3, clanName: 'Plantilla Maracay', leader: 'NovaQueen', rounds: 17, kills: 119, booyahs: 5, points: 8930 },
  ]).map((clan) => ({
    ...clan,
    rounds: clan.rounds ?? 0,
    kills: clan.kills ?? 0,
    booyahs: clan.booyahs ?? 0,
  }));
export const saveClans = (clans: ClanRank[]) => writeList(storageKeys.clans, clans);

export const getSchedule = () => normalizeSchedule(readList<ScheduleSlot>(storageKeys.schedule, defaultSchedule()));
export const saveSchedule = (schedule: ScheduleSlot[]) => writeList(storageKeys.schedule, schedule);

export const getHomeMedia = () => readValue<HomeMedia>(storageKeys.homeMedia);
export const saveHomeMedia = (media: HomeMedia) => writeValue(storageKeys.homeMedia, media);
export const removeHomeMedia = () => localStorage.removeItem(storageKeys.homeMedia);

export const pageLabels: Record<PageKey, string> = {
  inicio: 'Inicio',
  inscripcion: 'Inscripción',
  horario: 'Horario',
  clasificacion: 'Tabla de Clasificación',
  diamantes: 'Recarga de Diamante',
  cuentas: 'Compra y Venta de Cuenta',
};

export const pageKeys = Object.keys(pageLabels) as PageKey[];

export const getAllPageMedia = () => readValue<Partial<Record<PageKey, PageMedia>>>(storageKeys.pageMedia) ?? {};

export const getPageMedia = (page: PageKey) => {
  const media = getAllPageMedia()[page] ?? null;
  return page === 'inicio' ? media ?? getHomeMedia() : media;
};

export const savePageMedia = (page: PageKey, media: PageMedia) => {
  const allMedia = getAllPageMedia();
  const nextMedia = { ...allMedia, [page]: media };
  writeValue(storageKeys.pageMedia, nextMedia);

  if (page === 'inicio') saveHomeMedia(media);
};

export const removePageMedia = (page: PageKey) => {
  const allMedia = getAllPageMedia();
  delete allMedia[page];
  writeValue(storageKeys.pageMedia, allMedia);

  if (page === 'inicio') removeHomeMedia();
};

const normalizeWhatsAppLinks = (links: unknown): WhatsAppLinks => {
  if (!links || typeof links !== 'object') return defaultWhatsAppLinks;

  const value = links as Partial<Record<keyof WhatsAppLinks, string | Partial<WhatsAppEntry>>>;
  const normalizeEntry = (key: keyof WhatsAppLinks): WhatsAppEntry => {
    const entry = value[key];
    if (typeof entry === 'string') return { ...defaultWhatsAppLinks[key], url: entry };

    return {
      url: entry?.url || defaultWhatsAppLinks[key].url,
      image: entry?.image || defaultWhatsAppLinks[key].image,
    };
  };

  return {
    battleRoyale: normalizeEntry('battleRoyale'),
    pvp: normalizeEntry('pvp'),
    clanes: normalizeEntry('clanes'),
  };
};

export const getWhatsAppLinks = () => normalizeWhatsAppLinks(readValue<unknown>(storageKeys.whatsappLinks));
export const saveWhatsAppLinks = (links: WhatsAppLinks) => writeValue(storageKeys.whatsappLinks, links);

export const getAdminCreds = () => readValue<{user: string, pass: string}>(storageKeys.adminCreds) ?? { user: 'cabellojeison28', pass: '85047928291526' };
export const saveAdminCreds = (creds: {user: string, pass: string}) => writeValue(storageKeys.adminCreds, creds);