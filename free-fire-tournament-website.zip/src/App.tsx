import { useEffect, useState, type ReactElement } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import DiamondsPage from './pages/DiamondsPage';
import AccountsPage from './pages/AccountsPage';
import RegistrationPage from './pages/RegistrationPage';
import DetailsPage from './pages/DetailsPage';
import SchedulePage from './pages/SchedulePage';
import ClanRankingPage from './pages/ClanRankingPage';
import WorkRequestPage from './pages/WorkRequestPage';
import EmpleadoPage from './pages/EmpleadoPage';
import AdminPage from './pages/AdminPage';
import { AppProvider } from './context/AppContext';

const getRoute = () => window.location.hash.replace('#/', '') || 'inicio';

function App() {
  const [route, setRoute] = useState(getRoute());

  useEffect(() => {
    const handleHashChange = () => {
      setRoute(getRoute());
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    if (!window.location.hash) window.location.hash = '#/inicio';
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const pages: Record<string, ReactElement> = {
    inicio: <HomePage />,
    diamantes: <DiamondsPage />,
    cuentas: <AccountsPage />,
    inscripcion: <RegistrationPage />,
    detalles: <DetailsPage />,
    horario: <SchedulePage />,
    clasificacion: <ClanRankingPage />,
    'solicitar-trabajo': <WorkRequestPage />,
    empleado: <EmpleadoPage />,
    administrador: <AdminPage />,
  };

  return (
    <AppProvider>
      <div className="min-h-screen overflow-x-hidden bg-black selection:bg-orange-500 selection:text-black">
        <Navbar />
        <main>{pages[route] ?? <HomePage />}</main>
        <Footer />
      </div>
    </AppProvider>
  );
}

export default App;
