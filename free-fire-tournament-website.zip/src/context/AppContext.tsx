import { createContext, useContext, useState, ReactNode } from 'react';
import { AccountListing, DiamondOffer } from '../lib/storage';

export interface Employee {
  id: string;
  name: string;
  logoName: string;
  access: string;
  password: string;
  active: boolean;
  phone: string;
}

export interface PageBackground {
  type: 'image' | 'video' | 'youtube';
  url: string;
  muted: boolean;
  brightness: number;
}

export type PageKey = 'inicio' | 'inscripcion' | 'horario' | 'clasificacion' | 'diamantes' | 'cuentas' | 'empleado';

export interface SeasonInfo {
  text: string;
  active: boolean;
}

interface AppContextType {
  employees: Employee[];
  setEmployees: (e: Employee[]) => void;
  pageBackgrounds: Record<PageKey, PageBackground>;
  setPageBackground: (page: PageKey, bg: PageBackground) => void;
  accountListings: AccountListing[];
  addAccountListing: (listing: AccountListing) => void;
  removeAccountListing: (id: string) => void;
  updateAccountListing: (id: string, listing: AccountListing) => void;
  diamondOffers: DiamondOffer[];
  addDiamondOffer: (offer: DiamondOffer) => void;
  removeDiamondOffer: (id: string) => void;
  updateDiamondOffer: (id: string, offer: DiamondOffer) => void;
  seasonInfo: SeasonInfo;
  setSeasonInfo: (info: SeasonInfo) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const useAppContext = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within AppProvider');
  return ctx;
};

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [pageBackgrounds, setPageBackgrounds] = useState<Record<PageKey, PageBackground>>({
    inicio: { type: 'image', url: '/images/hero-bg.jpg', muted: false, brightness: 100 },
    inscripcion: { type: 'image', url: '/images/hero-bg.jpg', muted: false, brightness: 100 },
    horario: { type: 'image', url: '/images/horario-bg.jpg', muted: false, brightness: 100 },
    clasificacion: { type: 'image', url: '/images/ranking-bg.jpg', muted: false, brightness: 100 },
    diamantes: { type: 'image', url: '/images/hero-bg.jpg', muted: false, brightness: 100 },
    cuentas: { type: 'image', url: '/images/hero-bg.jpg', muted: false, brightness: 100 },
    empleado: { type: 'image', url: '/images/hero-bg.jpg', muted: false, brightness: 100 },
  });

  const [accountListings, setAccountListings] = useState<AccountListing[]>([]);
  const [diamondOffers, setDiamondOffers] = useState<DiamondOffer[]>([]);
  const [seasonInfo, setSeasonInfo] = useState<SeasonInfo>({ text: 'TEMPORADA 2026 ACTIVA', active: true });

  const setPageBackground = (page: PageKey, bg: PageBackground) => {
    setPageBackgrounds(prev => ({ ...prev, [page]: bg }));
  };

  const addAccountListing = (listing: AccountListing) => setAccountListings(prev => [...prev, listing]);
  const removeAccountListing = (id: string) => setAccountListings(prev => prev.filter(a => a.id !== id));
  const updateAccountListing = (id: string, updatedListing: AccountListing) => {
    setAccountListings(prev => prev.map(a => a.id === id ? updatedListing : a));
  };

  const addDiamondOffer = (offer: DiamondOffer) => setDiamondOffers(prev => [...prev, offer]);
  const removeDiamondOffer = (id: string) => setDiamondOffers(prev => prev.filter(o => o.id !== id));
  const updateDiamondOffer = (id: string, updatedOffer: DiamondOffer) => {
    setDiamondOffers(prev => prev.map(o => o.id === id ? updatedOffer : o));
  };

  return (
    <AppContext.Provider value={{ 
        employees, setEmployees, pageBackgrounds, setPageBackground, 
        accountListings, addAccountListing, removeAccountListing, updateAccountListing, 
        diamondOffers, addDiamondOffer, removeDiamondOffer, updateDiamondOffer,
        seasonInfo, setSeasonInfo
    }}>
      {children}
    </AppContext.Provider>
  );
};
